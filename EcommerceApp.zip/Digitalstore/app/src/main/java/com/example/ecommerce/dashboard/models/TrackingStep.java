package com.example.ecommerce.dashboard.models;

public class TrackingStep {

    private String status;
    private boolean completed;
    private String date;

    public TrackingStep(String status, boolean completed, String date) {
        this.status = status != null ? status : "N/A";
        this.completed = completed;
        this.date = date != null ? date : "";
    }

    public String getStatus() { return status; }
    public boolean isCompleted() { return completed; }
    public String getDate() { return date; }

    public void setStatus(String status) {
        this.status = status != null ? status : "N/A";
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public void setDate(String date) {
        this.date = date != null ? date : "";
    }
}
