package com.example.ecommerce.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "order_details")
public class OrderDetail {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public int orderId;     // foreign key reference to OrderItem.id
    public String productName;
    public int quantity;
    public double price;

    public OrderDetail(int id, int orderId, String productName, int quantity, double price) {
        this.id = id;
        this.orderId = orderId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }
}
