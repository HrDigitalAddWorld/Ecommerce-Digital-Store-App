package com.example.ecommerce.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.models.CartItem;
import com.example.ecommerce.ui.auth.LoginActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CheckoutActivity extends AppCompatActivity implements PaymentResultListener {

    private ArrayList<CartItem> cartList;
    private double subtotal, platformCharge = 20, gstRate = 0.02, grandTotal;

    private FirebaseAuth auth;
    private FirebaseFirestore db;

    private TextView tvSubtotal, tvPlatformCharge, tvGST, tvGrandTotal, tvSummary;
    private RadioGroup rgPaymentMethod;
    private RadioButton rbCOD, rbRazorpay;
    private Button btnConfirm;

    private static final String TAG = "CheckoutActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        // Init Firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Razorpay setup
        Checkout.preload(getApplicationContext());

        // Init views
        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvPlatformCharge = findViewById(R.id.tvPlatformCharge);
        tvGST = findViewById(R.id.tvGST);
        tvGrandTotal = findViewById(R.id.tvGrandTotal);
        tvSummary = findViewById(R.id.tvSummary);
        rgPaymentMethod = findViewById(R.id.rgPaymentMethod);
        rbCOD = findViewById(R.id.rbCOD);
        rbRazorpay = findViewById(R.id.rbRazorpay);
        btnConfirm = findViewById(R.id.btnConfirm);

        // Get intent data
        subtotal = getIntent().getDoubleExtra("subtotal", 0);
        cartList = (ArrayList<CartItem>) getIntent().getSerializableExtra("cartList");
        if (cartList == null) cartList = new ArrayList<>();

        displaySummary();
        calculateTotals();

        btnConfirm.setOnClickListener(v -> handlePayment());
    }

    private void displaySummary() {
        StringBuilder summary = new StringBuilder();
        for (CartItem item : cartList) {
            summary.append(item.getName())
                    .append(" x ")
                    .append(item.getQuantity())
                    .append(" = ₹")
                    .append(Double.parseDouble(item.getPrice()) * item.getQuantity())
                    .append("\nMerchant: ")
                    .append(item.getMerchantUid())
                    .append("\n\n");
        }
        tvSummary.setText(summary.toString());
    }

    private void calculateTotals() {
        double gst = subtotal * gstRate;
        grandTotal = subtotal + platformCharge + gst;

        tvSubtotal.setText("Subtotal: ₹" + String.format("%.2f", subtotal));
        tvPlatformCharge.setText("Platform Charge: ₹" + String.format("%.2f", platformCharge));
        tvGST.setText("GST 2%: ₹" + String.format("%.2f", gst));
        tvGrandTotal.setText("Grand Total: ₹" + String.format("%.2f", grandTotal));
    }

    private void handlePayment() {
        int selectedId = rgPaymentMethod.getCheckedRadioButtonId();
        if (selectedId == -1) {
            Toast.makeText(this, "Select a payment method", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedId == R.id.rbCOD) {
            placeOrder("Cash On Delivery");
        } else if (selectedId == R.id.rbRazorpay) {
            startRazorpayPayment();
        }
    }

    private void startRazorpayPayment() {
        Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_RTLP6S5D6Kswyh"); // Razorpay Test Key

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Digital Store");
            options.put("description", "Order Payment");
            options.put("currency", "INR");
            options.put("amount", (int) (grandTotal * 100)); // Convert to paise
            options.put("theme.color", "#3399cc");

            JSONObject prefill = new JSONObject();
            prefill.put("email", auth.getCurrentUser() != null ? auth.getCurrentUser().getEmail() : "test@digitalstore.com");
            prefill.put("contact", "9999999999");
            options.put("prefill", prefill);

            checkout.open(this, options);
        } catch (Exception e) {
            Log.e(TAG, "Error in starting Razorpay Checkout", e);
            Toast.makeText(this, "Error starting payment: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onPaymentSuccess(String razorpayPaymentID) {
        Toast.makeText(this, "Payment Successful: " + razorpayPaymentID, Toast.LENGTH_SHORT).show();
        placeOrder("Online Payment (Razorpay)");
    }

    @Override
    public void onPaymentError(int code, String response) {
        Toast.makeText(this, "Payment Failed: " + response, Toast.LENGTH_SHORT).show();
    }

    private void placeOrder(String paymentMethod) {
        if (auth.getCurrentUser() == null) {
            Toast.makeText(this, "Please login to place order", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            return;
        }

        String userId = auth.getCurrentUser().getUid();
        long timestamp = System.currentTimeMillis();
        String orderId = db.collection("orders").document().getId();

        Map<String, Object> orderData = new HashMap<>();
        orderData.put("orderId", orderId);
        orderData.put("userId", userId);
        orderData.put("items", cartList);
        orderData.put("subtotal", subtotal);
        orderData.put("platformCharge", platformCharge);
        orderData.put("gst", gstRate);
        orderData.put("grandTotal", grandTotal);
        orderData.put("orderAmount", grandTotal);
        orderData.put("paymentMethod", paymentMethod);
        orderData.put("status", "Pending");
        orderData.put("timestamp", timestamp);

        List<String> merchantUids = new ArrayList<>();
        for (CartItem item : cartList) {
            if (item.getMerchantUid() != null) merchantUids.add(item.getMerchantUid());
        }
        orderData.put("merchantUid", merchantUids);

        orderData.put("orderPlaced", true);
        orderData.put("shipped", false);
        orderData.put("outForDelivery", false);
        orderData.put("delivered", false);

        Map<String, Object> dates = new HashMap<>();
        dates.put("orderPlaced", timestampToDate(timestamp));
        dates.put("shipped", "");
        dates.put("outForDelivery", "");
        dates.put("delivered", "");
        orderData.put("dates", dates);

        db.collection("orders").document(orderId)
                .set(orderData)
                .addOnSuccessListener(aVoid -> {
                    clearCart(userId);
                    Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(this, DashboardActivity.class));
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to place order: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private void clearCart(String userId) {
        db.collection("users").document(userId).collection("cart").get()
                .addOnSuccessListener(querySnapshot -> {
                    for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                        db.collection("users").document(userId).collection("cart").document(doc.getId()).delete();
                    }
                });
    }

    private String timestampToDate(long timestamp) {
        return new java.text.SimpleDateFormat("MMM dd, yyyy", java.util.Locale.getDefault())
                .format(new java.util.Date(timestamp));
    }
}
