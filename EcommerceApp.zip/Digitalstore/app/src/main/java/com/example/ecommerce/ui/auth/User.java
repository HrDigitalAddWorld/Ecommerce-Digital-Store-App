package com.example.ecommerce.ui.auth;

public class User {

    private String name;
    private String email;
    private String uid;

    // Empty constructor required for Firestore
    public User() {
    }

    public User(String name, String email, String uid) {
        this.name = name;
        this.email = email;
        this.uid = uid;
    }

    // Getter methods
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getUid() { return uid; }

    // Setter methods
    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setUid(String uid) { this.uid = uid; }
}
