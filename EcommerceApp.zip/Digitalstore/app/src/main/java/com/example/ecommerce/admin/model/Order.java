package com.example.ecommerce.admin.model;

import java.util.Map;

public class Order {
    private String orderId;
    private String customerName;
    private String productName;
    private int qty;       // renamed
    private double amount; // renamed
    private Object status; // Can be String or Map

    public Order() { }

    public Order(String orderId, String customerName, String productName, int qty, double amount, Object status) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.productName = productName;
        this.qty = qty;
        this.amount = amount;
        this.status = status;
    }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getCustomerName() { return customerName; }
    public void setCustomerName(String customerName) { this.customerName = customerName; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public int getQty() { return qty; }
    public void setQty(int qty) { this.qty = qty; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public Object getStatus() { return status; }
    public void setStatus(Object status) { this.status = status; }

    public String getStatusString() {
        if (status instanceof String) {
            return (String) status;
        } else if (status instanceof Map) {
            Map map = (Map) status;
            if (map.containsKey("current")) {
                return map.get("current").toString();
            }
        }
        return "Unknown";
    }
}