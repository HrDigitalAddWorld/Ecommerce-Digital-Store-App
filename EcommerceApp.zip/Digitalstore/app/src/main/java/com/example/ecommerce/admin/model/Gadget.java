package com.example.ecommerce.admin.model;

public class Gadget {
    private String name;
    private Double price;  // <-- change to Double
    private String imageUrl;

    public Gadget() {} // Needed for Firestore

    public Gadget(String name, Double price, String imageUrl) {
        this.name = name;
        this.price = price;
        this.imageUrl = imageUrl;
    }

    public String getName() { return name; }
    public Double getPrice() { return price; }  // <-- returns Double
    public String getImageUrl() { return imageUrl; }

    public void setName(String name) { this.name = name; }
    public void setPrice(Double price) { this.price = price; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
}