package com.example.ecommerce.admin.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.CollectionReference;
import java.util.List;
import com.example.ecommerce.admin.model.Order;
import com.example.ecommerce.R;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private List<Order> orderList;
    private CollectionReference orderRef;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onEdit(Order order);
        void onDelete(Order order);
    }

    public OrderAdapter(List<Order> orderList, CollectionReference orderRef, OnItemClickListener listener) {
        this.orderList = orderList;
        this.orderRef = orderRef;
        this.listener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);

        // Only display Customer Name and Product Name
        holder.txtCustomer.setText(order.getCustomerName());
        holder.txtProduct.setText(order.getProductName());

        holder.btnEdit.setOnClickListener(v -> {
            if (listener != null) listener.onEdit(order);
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(order);
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView txtCustomer, txtProduct;
        ImageButton btnEdit, btnDelete;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            txtCustomer = itemView.findViewById(R.id.txtCustomer);
            txtProduct = itemView.findViewById(R.id.txtProduct);
            btnEdit = itemView.findViewById(R.id.btnEditOrder);
            btnDelete = itemView.findViewById(R.id.btnDeleteOrder);
        }
    }
}