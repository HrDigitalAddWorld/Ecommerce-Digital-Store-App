package com.example.ecommerce.admin;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.example.ecommerce.admin.Adapter.GadgetAdapter;
import com.example.ecommerce.admin.model.Gadget;
import com.example.ecommerce.R;
import java.util.ArrayList;
import java.util.List;

public class GadgetManagementActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 101;

    private EditText edtGadgetName, edtGadgetPrice;
    private Button btnSelectImage, btnAddGadget;
    private ImageView ivGadgetPreview;
    private RecyclerView recyclerGadgets;

    private Uri selectedImageUri;
    private FirebaseFirestore firestore;
    private List<Gadget> gadgetList;
    private GadgetAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gadget_management);

        edtGadgetName = findViewById(R.id.edtGadgetName);
        edtGadgetPrice = findViewById(R.id.edtGadgetPrice);
        btnSelectImage = findViewById(R.id.btnSelectImage);
        btnAddGadget = findViewById(R.id.btnAddGadget);
        ivGadgetPreview = findViewById(R.id.ivGadgetPreview);
        recyclerGadgets = findViewById(R.id.recyclerGadgets);

        firestore = FirebaseFirestore.getInstance();
        gadgetList = new ArrayList<>();
        adapter = new GadgetAdapter(gadgetList, this);
        recyclerGadgets.setLayoutManager(new LinearLayoutManager(this));
        recyclerGadgets.setAdapter(adapter);

        loadGadgetsFromFirestore();

        btnSelectImage.setOnClickListener(v -> openImagePicker());
        btnAddGadget.setOnClickListener(v -> addGadget());
    }

    private void openImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            ivGadgetPreview.setImageURI(selectedImageUri);
        }
    }

    private void addGadget() {
        String name = edtGadgetName.getText().toString().trim();
        String priceStr = edtGadgetPrice.getText().toString().trim();

        if (name.isEmpty() || priceStr.isEmpty() || selectedImageUri == null) {
            Toast.makeText(this, "Please fill all fields and select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        Double price;
        try {
            price = Double.parseDouble(priceStr);  // convert string to Double
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid price", Toast.LENGTH_SHORT).show();
            return;
        }

        String imageUrl = selectedImageUri.toString();
        Gadget gadget = new Gadget(name, price, imageUrl);

        firestore.collection("products")
                .add(gadget)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Gadget added", Toast.LENGTH_SHORT).show();
                    gadgetList.add(gadget);
                    adapter.notifyItemInserted(gadgetList.size() - 1);
                    clearInputs();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to add gadget", Toast.LENGTH_SHORT).show());
    }

    private void clearInputs() {
        edtGadgetName.setText("");
        edtGadgetPrice.setText("");
        ivGadgetPreview.setImageResource(R.drawable.ic_placeholder);
        selectedImageUri = null;
    }

    private void loadGadgetsFromFirestore() {
        firestore.collection("products")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        gadgetList.clear();
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            try {
                                Gadget g = doc.toObject(Gadget.class);
                                gadgetList.add(g);
                            } catch (Exception e) {
                                e.printStackTrace(); // handle type mismatch gracefully
                            }
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(this, "Failed to load gadgets", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}