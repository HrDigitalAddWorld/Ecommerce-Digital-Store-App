package com.example.ecommerce;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder> {

    private Context context;
    private List<Product> productList;
    private FirebaseFirestore db;

    public ProductAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
        db = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Product product = productList.get(position);

        holder.tvName.setText(product.getProductName());
        holder.tvPrice.setText("₹" + product.getPrice());

        // Load image from internal storage
        String imagePath = product.getImagePath();
        if (imagePath != null) {
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            holder.ivProduct.setImageBitmap(bitmap);
        } else {
            holder.ivProduct.setImageResource(R.drawable.ic_placeholder);
        }

        // Edit product
        holder.btnEdit.setOnClickListener(v -> showEditDialog(product, position));

        // Delete product
        holder.btnDelete.setOnClickListener(v -> showDeleteDialog(product, position));
    }

    private void showEditDialog(Product product, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Edit Product");

        LinearLayout layout = new LinearLayout(context);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20, 20, 20, 20);

        final EditText etName = new EditText(context);
        etName.setHint("Product Name");
        etName.setText(product.getProductName());
        layout.addView(etName);

        final EditText etPrice = new EditText(context);
        etPrice.setHint("Price");
        etPrice.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        etPrice.setText(String.valueOf(product.getPrice()));
        layout.addView(etPrice);

        final EditText etQuantity = new EditText(context);
        etQuantity.setHint("Quantity");
        etQuantity.setInputType(InputType.TYPE_CLASS_NUMBER);
        etQuantity.setText(String.valueOf(product.getQuantity()));
        layout.addView(etQuantity);

        builder.setView(layout);

        builder.setPositiveButton("Update", (dialog, which) -> {
            String newName = etName.getText().toString().trim();
            double newPrice = Double.parseDouble(etPrice.getText().toString().trim());
            int newQuantity = Integer.parseInt(etQuantity.getText().toString().trim());

            Map<String, Object> updatedData = new HashMap<>();
            updatedData.put("productName", newName);
            updatedData.put("price", newPrice);
            updatedData.put("quantity", newQuantity);

            db.collection("products").document(product.getId())
                    .update(updatedData)
                    .addOnSuccessListener(aVoid -> {
                        product.setProductName(newName);
                        product.setPrice(newPrice);
                        product.setQuantity(newQuantity);
                        notifyItemChanged(position);
                        Toast.makeText(context, "Product updated!", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(context, "Failed to update: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                    );
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private void showDeleteDialog(Product product, int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Delete Product");
        builder.setMessage("Are you sure you want to delete " + product.getProductName() + "?");

        builder.setPositiveButton("Delete", (dialog, which) -> {
            db.collection("products").document(product.getId())
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        productList.remove(position);
                        notifyItemRemoved(position);
                        Toast.makeText(context, "Product deleted", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(context, "Failed to delete: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                    );
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProduct;
        TextView tvName, tvPrice;
        Button btnEdit, btnDelete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivProduct = itemView.findViewById(R.id.ivProduct);
            tvName = itemView.findViewById(R.id.tvProductName);
            tvPrice = itemView.findViewById(R.id.tvProductPrice);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
