package com.example.ecommerce.data.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import androidx.room.Delete;
import java.util.List;

@Dao
public interface CartDao {

    @Insert
    void insertCartItem(CartItem item);  // <-- yeh method chahiye tha

    @Update
    void update(CartItem item);

    @Delete
    void delete(CartItem item);

    @Query("SELECT * FROM cart")
    List<CartItem> getAllCartItems();

    @Query("DELETE FROM cart")
    void clearCart();
}
