package com.example.ecommerce.dashboard.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.models.TrackingStep;

import java.util.List;

public class TrackingAdapter extends RecyclerView.Adapter<TrackingAdapter.TrackingViewHolder> {

    private List<TrackingStep> steps;

    public TrackingAdapter(List<TrackingStep> steps) {
        this.steps = steps;
    }

    @NonNull
    @Override
    public TrackingViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tracking_item, parent, false);
        return new TrackingViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TrackingViewHolder holder, int position) {
        TrackingStep step = steps.get(position);

        holder.statusText.setText(step.getStatus());
        holder.dateText.setText(step.getDate() != null ? step.getDate() : "");

        // Change circle color based on completion
        holder.statusCircle.setBackgroundResource(step.isCompleted() ? R.drawable.circle_green : R.drawable.circle_gray);
    }

    @Override
    public int getItemCount() {
        return steps.size();
    }

    public static class TrackingViewHolder extends RecyclerView.ViewHolder {
        TextView statusText, dateText;
        View statusCircle;

        public TrackingViewHolder(@NonNull View itemView) {
            super(itemView);
            statusText = itemView.findViewById(R.id.statusText);
            dateText = itemView.findViewById(R.id.dateText);
            statusCircle = itemView.findViewById(R.id.statusCircle);
        }
    }
}
