package com.example.ecommerce.dashboard.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.models.Order;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.OrderViewHolder> {

    private Context context;
    private List<Order> orderList;

    public OrderAdapter(Context context, List<Order> orderList) {
        this.context = context;
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.order_item, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orderList.get(position);

        holder.orderIdText.setText("Order ID: " + safeString(order.getOrderId()));
        holder.orderDateText.setText("Date: " + safeString(order.getOrderDate()));
        holder.orderAmountText.setText("Amount: ₹" + safeString(order.getGrandTotal()));
        holder.statusText.setText("Status: " + safeString(order.getStatus()));

        Map<String, Boolean> statusMap = order.getStatusMap();
        if (statusMap == null) statusMap = new HashMap<>();

        // Update timeline circles safely
        holder.shippedCircle.setBackgroundResource(Boolean.TRUE.equals(statusMap.get("shipped")) ? R.drawable.circle_green : R.drawable.circle_gray);
        holder.outForDeliveryCircle.setBackgroundResource(Boolean.TRUE.equals(statusMap.get("outForDelivery")) ? R.drawable.circle_green : R.drawable.circle_gray);
        holder.deliveredCircle.setBackgroundResource(Boolean.TRUE.equals(statusMap.get("delivered")) ? R.drawable.circle_green : R.drawable.circle_gray);
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    private String safeString(String value) {
        return value != null ? value : "N/A";
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView orderIdText, orderDateText, orderAmountText, statusText;
        View shippedCircle, outForDeliveryCircle, deliveredCircle;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            orderIdText = itemView.findViewById(R.id.orderIdText);
            orderDateText = itemView.findViewById(R.id.orderDateText);
            orderAmountText = itemView.findViewById(R.id.orderAmountText);
            statusText = itemView.findViewById(R.id.statusText);

            shippedCircle = itemView.findViewById(R.id.shippedCircle);
            outForDeliveryCircle = itemView.findViewById(R.id.outForDeliveryCircle);
            deliveredCircle = itemView.findViewById(R.id.deliveredCircle);
        }
    }
}
