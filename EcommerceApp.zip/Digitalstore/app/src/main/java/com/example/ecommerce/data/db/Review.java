package com.example.ecommerce.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Ignore;

@Entity(tableName = "reviews")
public class Review {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private int productId;     // 👈 foreign key reference to Product
    private String userName;
    private String comment;
    private float rating;

    public Review(int id, int productId, String userName, String comment, float rating) {
        this.id = id;
        this.productId = productId;
        this.userName = userName;
        this.comment = comment;
        this.rating = rating;
    }

    @Ignore
    public Review(int productId, String userName, String comment, float rating) {
        this.productId = productId;
        this.userName = userName;
        this.comment = comment;
        this.rating = rating;
    }

    // --- Getters & Setters ---
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public float getRating() { return rating; }
    public void setRating(float rating) { this.rating = rating; }
}
