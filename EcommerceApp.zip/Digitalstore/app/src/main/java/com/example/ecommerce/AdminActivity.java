package com.example.ecommerce;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.example.ecommerce.admin.SlideManagementActivity;
import com.example.ecommerce.admin.DealManagementActivity;
import com.example.ecommerce.admin.OrderManagementActivity;
import com.example.ecommerce.admin.PaymentSettlementActivity;
import com.example.ecommerce.admin.ProductManagementActivity;
import com.example.ecommerce.admin.FooterManagementActivity;
import com.example.ecommerce.admin.GadgetManagementActivity;
import com.example.ecommerce.admin.TestimonialManagementActivity;
import com.example.ecommerce.admin.UserManagementActivity;
import com.example.ecommerce.admin.UserPaymentsActivity;
import com.example.ecommerce.admin.BusinessSellerManagementActivity;


public class AdminActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        // Slide Management
        findViewById(R.id.btnSlideManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, SlideManagementActivity.class))
        );

        // Deal Management
        findViewById(R.id.btnDealManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, DealManagementActivity.class))
        );

        // Gadget Management
        findViewById(R.id.btnGadgetManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, GadgetManagementActivity.class))
        );

        // Testimonial Management
        findViewById(R.id.btnTestimonialManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, TestimonialManagementActivity.class))
        );

        // Footer Management
        findViewById(R.id.btnFooterManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, FooterManagementActivity.class))
        );

        // User Management
        findViewById(R.id.btnUserManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, UserManagementActivity.class))
        );

        // Business Seller Management
        findViewById(R.id.btnBusinessSellerManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, BusinessSellerManagementActivity.class))
        );

        // Payment Settlement
        findViewById(R.id.btnPaymentSettlement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, PaymentSettlementActivity.class))
        );

        // Product Management
        findViewById(R.id.btnProductManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, ProductManagementActivity.class))
        );

        // Order Management
        findViewById(R.id.btnOrderManagement).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, OrderManagementActivity.class))
        );

        // User Payments
        findViewById(R.id.btnUserPayments).setOnClickListener(v ->
                startActivity(new Intent(AdminActivity.this, UserPaymentsActivity.class))
        );

        // Logout Button (at the bottom of ScrollView)
        Button logoutBtn = findViewById(R.id.btnLogout);
        logoutBtn.setOnClickListener(v -> {
            startActivity(new Intent(AdminActivity.this, AdminLoginActivity.class));
            finish();
        });
    }
}