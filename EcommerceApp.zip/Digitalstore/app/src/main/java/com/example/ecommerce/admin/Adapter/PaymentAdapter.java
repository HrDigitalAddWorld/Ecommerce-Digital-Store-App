package com.example.ecommerce.admin.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.CollectionReference;
import com.example.ecommerce.admin.model.Payment;
import java.util.List;
import com.example.ecommerce.R;

public class PaymentAdapter extends RecyclerView.Adapter<PaymentAdapter.PaymentViewHolder> {

    private List<Payment> paymentList;
    private CollectionReference paymentRef;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onEdit(Payment payment);
        void onDelete(Payment payment);
    }

    public PaymentAdapter(List<Payment> paymentList, CollectionReference paymentRef, OnItemClickListener listener) {
        this.paymentList = paymentList;
        this.paymentRef = paymentRef;
        this.listener = listener;
    }

    @NonNull
    @Override
    public PaymentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_payment, parent, false);
        return new PaymentViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PaymentViewHolder holder, int position) {
        Payment payment = paymentList.get(position);

        holder.txtUser.setText(payment.getUserName());
        holder.txtAmount.setText("₹" + payment.getAmount());
        holder.txtMethod.setText(payment.getMethod());
        holder.txtStatus.setText(payment.getStatus());

        holder.btnEdit.setOnClickListener(v -> {
            if (listener != null) listener.onEdit(payment);
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (listener != null) listener.onDelete(payment);
        });
    }

    @Override
    public int getItemCount() {
        return paymentList.size();
    }

    public static class PaymentViewHolder extends RecyclerView.ViewHolder {
        TextView txtUser, txtAmount, txtMethod, txtStatus;
        ImageButton btnEdit, btnDelete;

        public PaymentViewHolder(@NonNull View itemView) {
            super(itemView);
            txtUser = itemView.findViewById(R.id.txtPaymentUser);
            txtAmount = itemView.findViewById(R.id.txtPaymentAmount);
            txtMethod = itemView.findViewById(R.id.txtPaymentMethod);
            txtStatus = itemView.findViewById(R.id.txtPaymentStatus);
            btnEdit = itemView.findViewById(R.id.btnEditPayment);
            btnDelete = itemView.findViewById(R.id.btnDeletePayment);
        }
    }
}