package com.example.ecommerce;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ecommerce.dashboard.DashboardActivity;
import com.example.ecommerce.ui.auth.LoginActivity;
import com.example.ecommerce.ui.merchant.MerchantLoginActivity;
import com.example.ecommerce.ui.auth.SignupActivity;

public class StoreActivity extends AppCompatActivity {

    private Button btnLogin, btnSignup, btnGuest, btnAdmin, btnMerchant;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Make full-screen (behind status bar)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            );
        }

        setContentView(R.layout.activity_store);

        // Bind buttons
        btnLogin = findViewById(R.id.btnLogin);
       // btnSignup = findViewById(R.id.btnSignup);
        btnGuest = findViewById(R.id.btnGuest);
        btnAdmin = findViewById(R.id.btnAdmin);
        btnMerchant = findViewById(R.id.btnMerchant);

        // Handle Login click
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Open LoginActivity
                Intent intent = new Intent(StoreActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        // Handle Signup click
//        btnSignup.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(StoreActivity.this, SignupActivity.class);
//                startActivity(intent);
//            }
//        });

        // Handle Guest click
        btnGuest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StoreActivity.this, DashboardActivity.class);
                // Pass a flag indicating guest mode
                intent.putExtra("IS_GUEST", true);
                startActivity(intent);
            }
        });


        // Handle Admin click
        btnAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StoreActivity.this, AdminLoginActivity.class);
                startActivity(intent);
            }
        });

        // Handle Merchant click
        btnMerchant.setOnClickListener(view -> {
            Intent intent = new Intent(StoreActivity.this, MerchantLoginActivity.class);
            startActivity(intent);
        });
    }
}
