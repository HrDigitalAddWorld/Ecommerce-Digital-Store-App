package com.example.ecommerce.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Ignore;

@Entity(tableName = "wishlist")
public class WishlistItem {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String name;
    private double price;
    private int imageRes;

    // Constructor used by Room (no @Ignore)
    public WishlistItem(int id, String name, double price, int imageRes) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.imageRes = imageRes;
    }

    // Convenience constructor (ignored by Room)
    @Ignore
    public WishlistItem(String name, double price, int imageRes) {
        this.name = name;
        this.price = price;
        this.imageRes = imageRes;
    }

    // --- Getters & Setters ---
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getImageRes() {
        return imageRes;
    }

    public void setImageRes(int imageRes) {
        this.imageRes = imageRes;
    }
}
