package com.example.ecommerce.dashboard.models;

import java.util.Map;

public class Order {

    private String orderId;
    private String orderDate;
    private String grandTotal;
    private String status;       // Display status (e.g., Pending, Shipped)
    private String merchantUid;  // Comma-separated merchant UIDs
    private Map<String, Boolean> statusMap; // For timeline tracking

    public Order(String orderId, String orderDate, String grandTotal, String status, String merchantUid, Map<String, Boolean> statusMap) {
        this.orderId = orderId != null ? orderId : "N/A";
        this.orderDate = orderDate != null ? orderDate : "N/A";
        this.grandTotal = grandTotal != null ? grandTotal : "0";
        this.status = status != null ? status : "Pending";
        this.merchantUid = merchantUid != null ? merchantUid : "N/A";
        this.statusMap = statusMap;
    }

    // Getters
    public String getOrderId() { return orderId; }
    public String getOrderDate() { return orderDate; }
    public String getGrandTotal() { return grandTotal; }
    public String getStatus() { return status; }
    public String getMerchantUid() { return merchantUid; }
    public Map<String, Boolean> getStatusMap() { return statusMap; }

    // Setters
    public void setStatus(String status) {
        this.status = status != null ? status : "Pending";
    }

    public void setMerchantUid(String merchantUid) {
        this.merchantUid = merchantUid != null ? merchantUid : "N/A";
    }

    public void setStatusMap(Map<String, Boolean> statusMap) {
        this.statusMap = statusMap;
    }
}
