
package com.example.ecommerce.ui.merchant;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ecommerce.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import com.example.ecommerce.MerchantActivity; // Correct import

public class MerchantLoginActivity extends AppCompatActivity {

    private EditText etMerchantName, etStoreName, etPhoneNumber, etGstNumber, etEmailRegister, etPasswordRegister;
    private EditText etEmailLogin, etPasswordLogin;
    private Button btnRegisterMerchant, btnLoginMerchant, btnToggleRegister, btnToggleLogin;
    private LinearLayout layoutRegister, layoutLogin;
    private FirebaseAuth auth;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_login);

        // Firebase
        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        // Toggle layouts
        layoutRegister = findViewById(R.id.layoutRegister);
        layoutLogin = findViewById(R.id.layoutLogin);
        btnToggleRegister = findViewById(R.id.btnToggleRegister);
        btnToggleLogin = findViewById(R.id.btnToggleLogin);

        btnToggleRegister.setOnClickListener(v -> {
            layoutRegister.setVisibility(LinearLayout.VISIBLE);
            layoutLogin.setVisibility(LinearLayout.GONE);
        });

        btnToggleLogin.setOnClickListener(v -> {
            layoutRegister.setVisibility(LinearLayout.GONE);
            layoutLogin.setVisibility(LinearLayout.VISIBLE);
        });

        // Registration fields
        etMerchantName = findViewById(R.id.etMerchantName);
        etStoreName = findViewById(R.id.etStoreName);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etGstNumber = findViewById(R.id.etGstNumber);
        etEmailRegister = findViewById(R.id.etEmailRegister);
        etPasswordRegister = findViewById(R.id.etPasswordRegister);
        btnRegisterMerchant = findViewById(R.id.btnRegisterMerchant);

        // Login fields
        etEmailLogin = findViewById(R.id.etEmailLogin);
        etPasswordLogin = findViewById(R.id.etPasswordLogin);
        btnLoginMerchant = findViewById(R.id.btnLoginMerchant);

        btnRegisterMerchant.setOnClickListener(v -> registerMerchant());
        btnLoginMerchant.setOnClickListener(v -> loginMerchant());
    }

    private void registerMerchant() {
        String merchantName = etMerchantName.getText().toString().trim();
        String storeName = etStoreName.getText().toString().trim();
        String phone = etPhoneNumber.getText().toString().trim();
        String gst = etGstNumber.getText().toString().trim();
        String email = etEmailRegister.getText().toString().trim();
        String password = etPasswordRegister.getText().toString().trim();

        if (TextUtils.isEmpty(merchantName) || TextUtils.isEmpty(storeName) || TextUtils.isEmpty(phone)
                || TextUtils.isEmpty(gst) || TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener(result -> {
                    String merchantUid = result.getUser().getUid();

                    Map<String, Object> merchantData = new HashMap<>();
                    merchantData.put("merchantName", merchantName);
                    merchantData.put("storeName", storeName);
                    merchantData.put("merchantUid", merchantUid);
                    merchantData.put("phoneNumber", phone);
                    merchantData.put("gstNumber", gst);
                    merchantData.put("email", email);
                    merchantData.put("createdAt", System.currentTimeMillis());

                    firestore.collection("merchants")
                            .document(merchantUid)
                            .set(merchantData)
                            .addOnSuccessListener(aVoid -> {
                                Toast.makeText(this, "Merchant registered successfully!", Toast.LENGTH_SHORT).show();
                                goToMerchantHome(storeName);
                            })
                            .addOnFailureListener(e -> Toast.makeText(this, "Failed to save data: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Registration failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void loginMerchant() {
        String email = etEmailLogin.getText().toString().trim();
        String password = etPasswordLogin.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener(authResult -> {
                    String uid = authResult.getUser().getUid();

                    // Fetch merchant data to get storeName
                    firestore.collection("merchants").document(uid).get()
                            .addOnSuccessListener(documentSnapshot -> {
                                if (documentSnapshot.exists()) {
                                    String storeName = documentSnapshot.getString("storeName");
                                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();
                                    goToMerchantHome(storeName);
                                } else {
                                    Toast.makeText(this, "Merchant data not found!", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .addOnFailureListener(e -> Toast.makeText(this, "Error fetching data: " + e.getMessage(), Toast.LENGTH_SHORT).show());

                })
                .addOnFailureListener(e -> Toast.makeText(this, "Login failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // Open activity_merchant.xml and pass storeName
    private void goToMerchantHome(String storeName) {
        Intent intent = new Intent(MerchantLoginActivity.this, MerchantActivity.class);
        intent.putExtra("storeName", storeName);
        startActivity(intent);
        finish();
    }
}
