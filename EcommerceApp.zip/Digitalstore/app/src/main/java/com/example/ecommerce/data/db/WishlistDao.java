package com.example.ecommerce.data.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Delete;
import java.util.List;

@Dao
public interface WishlistDao {

    @Insert
    void insertWishlistItem(WishlistItem item);

    @Delete
    void deleteWishlistItem(WishlistItem item);
    @Query("DELETE FROM wishlist")
    void clearWishlist();

    @Query("SELECT * FROM wishlist")
    List<WishlistItem> getAllWishlistItems();
}
