package com.example.ecommerce;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MerchantActivity extends AppCompatActivity {

    LinearLayout cardAddProduct, cardManageProducts, cardViewOrders, cardEarnings;
    TextView tvStoreName, tvSubTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant); // XML layout file

        // Initialize store name
        tvStoreName = findViewById(R.id.tvStoreName);
        tvSubTitle = findViewById(R.id.tvSubTitle);

        // Get store name from intent
        String storeName = getIntent().getStringExtra("storeName");
        if (storeName != null) {
            tvStoreName.setText(storeName); // show store name
        }

        // Initialize cards
        cardAddProduct = findViewById(R.id.cardAddProduct);
        cardManageProducts = findViewById(R.id.cardManageProducts);
        cardViewOrders = findViewById(R.id.cardViewOrders);
        cardEarnings = findViewById(R.id.cardEarnings);

        // Click listeners
        cardAddProduct.setOnClickListener(v ->
                startActivity(new android.content.Intent(MerchantActivity.this, AddProductActivity.class)));

        cardManageProducts.setOnClickListener(v ->
                startActivity(new android.content.Intent(MerchantActivity.this, ManageProductActivity.class)));

        cardViewOrders.setOnClickListener(v ->
                startActivity(new android.content.Intent(MerchantActivity.this, MerchantViewOrdersActivity.class)));

        cardEarnings.setOnClickListener(v ->
                startActivity(new android.content.Intent(MerchantActivity.this, EarningsActivity.class)));
    }
}
