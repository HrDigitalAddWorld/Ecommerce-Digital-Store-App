package com.example.ecommerce.dashboard.models;

public class Product {
    private String id;
    private String name;
    private String imagePath;
    private String price;
    private String description;
    private String quantity;
    private String merchantUid; // UID of merchant

    // Default constructor required by Firestore
    public Product() {}

    // Full constructor
    public Product(String id, String name, String imagePath, String price,
                   String description, String quantity, String merchantUid) {
        this.id = id;
        this.name = name;
        this.imagePath = imagePath;
        this.price = price;
        this.description = description;
        this.quantity = quantity;
        this.merchantUid = merchantUid;
    }

    // Getters & setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getQuantity() { return quantity; }
    public void setQuantity(String quantity) { this.quantity = quantity; }

    public String getMerchantUid() { return merchantUid; }
    public void setMerchantUid(String merchantUid) { this.merchantUid = merchantUid; }
}
