package com.example.ecommerce.data.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.ecommerce.data.db.OrderProduct;

import java.util.List;

@Dao
public interface OrderProductDao {

    @Insert
    void insertOrderProducts(List<OrderProduct> products);  // <-- Add this

    @Query("SELECT * FROM order_products WHERE orderId = :orderId")
    List<OrderProduct> getProductsForOrder(int orderId);
}
