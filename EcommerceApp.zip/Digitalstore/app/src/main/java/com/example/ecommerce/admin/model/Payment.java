package com.example.ecommerce.admin.model;

public class Payment {
    private String paymentId;
    private String userName;   // User who made the payment
    private double amount;     // Payment amount
    private String method;     // Payment method (e.g., UPI, Card)
    private String status;     // Status (Paid / Pending / Failed)

    public Payment() { }

    public Payment(String paymentId, String userName, double amount, String method, String status) {
        this.paymentId = paymentId;
        this.userName = userName;
        this.amount = amount;
        this.method = method;
        this.status = status;
    }

    public String getPaymentId() { return paymentId; }
    public void setPaymentId(String paymentId) { this.paymentId = paymentId; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getMethod() { return method; }
    public void setMethod(String method) { this.method = method; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}