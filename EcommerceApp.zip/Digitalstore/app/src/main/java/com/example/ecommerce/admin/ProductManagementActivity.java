package com.example.ecommerce.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.example.ecommerce.admin.Adapter.ProductAdapter;
import com.example.ecommerce.admin.model.Product;
import com.example.ecommerce.R;
import java.util.ArrayList;
import java.util.List;

public class ProductManagementActivity extends AppCompatActivity {

    private RecyclerView recyclerViewProducts;
    private ProductAdapter adapter;
    private List<Product> productList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_management);

        recyclerViewProducts = findViewById(R.id.recyclerViewProducts);
        productList = new ArrayList<>();

        db = FirebaseFirestore.getInstance();

        adapter = new ProductAdapter(this, productList, new ProductAdapter.OnItemClickListener() {
            @Override
            public void onEdit(Product product) {
                showProductDialog(product, true);
            }

            @Override
            public void onDelete(Product product) {
                if (product.getId() == null || product.getId().isEmpty()) {
                    Toast.makeText(ProductManagementActivity.this, "Cannot delete: Invalid product ID", Toast.LENGTH_SHORT).show();
                    return;
                }

                db.collection("products").document(product.getId()).delete()
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(ProductManagementActivity.this, "Product Deleted", Toast.LENGTH_SHORT).show();
                            loadProducts();
                        })
                        .addOnFailureListener(e -> Toast.makeText(ProductManagementActivity.this, "Failed to delete product: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });

        recyclerViewProducts.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewProducts.setAdapter(adapter);

        findViewById(R.id.btnAddProduct).setOnClickListener(v -> showProductDialog(null, false));

        loadProducts();
    }

    private void loadProducts() {
        db.collection("products").get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    productList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Product product = doc.toObject(Product.class);
                        product.setId(doc.getId()); // Important: set the ID from Firestore doc
                        productList.add(product);
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Toast.makeText(ProductManagementActivity.this, "Failed to load products: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void showProductDialog(Product product, boolean isEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isEdit ? "Edit Product" : "Add Product");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText nameInput = new EditText(this);
        nameInput.setHint("Product Name");
        if (isEdit) nameInput.setText(product.getName());
        layout.addView(nameInput);

        final EditText descInput = new EditText(this);
        descInput.setHint("Description");
        if (isEdit) descInput.setText(product.getDescription());
        layout.addView(descInput);

        final EditText priceInput = new EditText(this);
        priceInput.setHint("Price");
        priceInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (isEdit) priceInput.setText(String.valueOf(product.getPrice())); // convert double to String
        layout.addView(priceInput);

        builder.setView(layout);

        builder.setPositiveButton(isEdit ? "Update" : "Add", (dialog, which) -> {
            String name = nameInput.getText().toString().trim();
            String desc = descInput.getText().toString().trim();
            String priceStr = priceInput.getText().toString().trim();

            if (!name.isEmpty() && !desc.isEmpty() && !priceStr.isEmpty()) {
                double price;
                try {
                    price = Double.parseDouble(priceStr); // convert input to double
                } catch (NumberFormatException e) {
                    Toast.makeText(this, "Invalid price", Toast.LENGTH_SHORT).show();
                    return;
                }

                String id;
                if (isEdit) {
                    id = product.getId();
                } else {
                    id = db.collection("products").document().getId(); // generate new doc ID
                }

                Product newProduct = new Product(id, name, desc, price, "");

                db.collection("products").document(id).set(newProduct)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(this, isEdit ? "Product Updated" : "Product Added", Toast.LENGTH_SHORT).show();
                            loadProducts();
                        })
                        .addOnFailureListener(e -> Toast.makeText(this, "Failed to save product: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "All fields required", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}