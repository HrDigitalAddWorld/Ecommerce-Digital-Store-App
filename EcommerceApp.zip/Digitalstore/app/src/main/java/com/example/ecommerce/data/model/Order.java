package com.example.ecommerce.data.model;

public class Order {
    public int id;
    public String productName;
    public int quantity;
    public double totalPrice;
    public String date;

    public Order(int id, String productName, int quantity, double totalPrice, String date) {
        this.id = id;
        this.productName = productName;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
        this.date = date;
    }
}
