package com.example.ecommerce;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;
import java.util.Map;

public class MerchantOrderAdapter extends RecyclerView.Adapter<MerchantOrderAdapter.MerchantOrderViewHolder> {

    private Context context;
    private List<MerchantOrder> orderList;

    public MerchantOrderAdapter(Context context, List<MerchantOrder> orderList) {
        this.context = context;
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public MerchantOrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.merchantorder_item, parent, false);
        return new MerchantOrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MerchantOrderViewHolder holder, int position) {
        MerchantOrder order = orderList.get(position);

        holder.orderIdText.setText("Order ID: " + order.getOrderId());
        holder.orderDateText.setText("Date: " + order.getOrderDate());
        holder.orderAmountText.setText("Amount: ₹" + order.getOrderAmount());

        Map<String, Boolean> statusMap = order.getStatus();
        holder.statusText.setText("Status: " + getCurrentStage(statusMap));

        updateTimeline(holder, statusMap);

        holder.updateStatusButton.setText(getNextStatusText(statusMap));
        holder.updateStatusButton.setOnClickListener(v -> {
            String nextStatusKey = getNextStatusKey(statusMap);
            if (nextStatusKey == null) return;

            FirebaseFirestore.getInstance()
                    .collection("orders")
                    .document(order.getDocId())
                    .update("status." + nextStatusKey, true)
                    .addOnSuccessListener(aVoid -> {
                        statusMap.put(nextStatusKey, true);
                        notifyItemChanged(position);
                    });
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class MerchantOrderViewHolder extends RecyclerView.ViewHolder {
        TextView orderIdText, orderDateText, orderAmountText, statusText;
        Button updateStatusButton;
        View shippedCircle, outForDeliveryCircle, deliveredCircle;

        public MerchantOrderViewHolder(@NonNull View itemView) {
            super(itemView);
            orderIdText = itemView.findViewById(R.id.orderIdText);
            orderDateText = itemView.findViewById(R.id.orderDateText);
            orderAmountText = itemView.findViewById(R.id.orderAmountText);
            statusText = itemView.findViewById(R.id.statusText);
            updateStatusButton = itemView.findViewById(R.id.updateStatusButton);
            shippedCircle = itemView.findViewById(R.id.shippedCircle);
            outForDeliveryCircle = itemView.findViewById(R.id.outForDeliveryCircle);
            deliveredCircle = itemView.findViewById(R.id.deliveredCircle);
        }
    }

    private void updateTimeline(MerchantOrderViewHolder holder, Map<String, Boolean> statusMap) {
        int activeColor = ContextCompat.getColor(context, R.color.green);
        int inactiveColor = ContextCompat.getColor(context, R.color.gray);

        holder.shippedCircle.setBackgroundColor(isTrue(statusMap, "shipped") ? activeColor : inactiveColor);
        holder.outForDeliveryCircle.setBackgroundColor(isTrue(statusMap, "outForDelivery") ? activeColor : inactiveColor);
        holder.deliveredCircle.setBackgroundColor(isTrue(statusMap, "delivered") ? activeColor : inactiveColor);
    }

    private String getNextStatusKey(Map<String, Boolean> statusMap) {
        if (!isTrue(statusMap, "shipped")) return "shipped";
        if (!isTrue(statusMap, "outForDelivery")) return "outForDelivery";
        if (!isTrue(statusMap, "delivered")) return "delivered";
        return null;
    }

    private String getNextStatusText(Map<String, Boolean> statusMap) {
        String key = getNextStatusKey(statusMap);
        if (key == null) return "Completed";
        switch (key) {
            case "shipped": return "Mark as Shipped";
            case "outForDelivery": return "Mark Out for Delivery";
            case "delivered": return "Mark as Delivered";
        }
        return "Update";
    }

    private String getCurrentStage(Map<String, Boolean> statusMap) {
        if (!isTrue(statusMap, "shipped")) return "Order Placed";
        if (!isTrue(statusMap, "outForDelivery")) return "Shipped";
        if (!isTrue(statusMap, "delivered")) return "Out for Delivery";
        return "Delivered";
    }

    private boolean isTrue(Map<String, Boolean> map, String key) {
        Boolean val = map.get(key);
        return val != null && val;
    }
}
