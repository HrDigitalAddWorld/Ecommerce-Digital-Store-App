package com.example.ecommerce;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminLoginActivity extends AppCompatActivity {

    private EditText adminEmail, adminPassword;
    private Button adminLoginButton, backToUserLogin;

    // ✅ Fixed Admin credentials (you can change these)
    private static final String ADMIN_EMAIL = "shri@gmail.com";
    private static final String ADMIN_PASSWORD = "aks2";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        // 🔗 Bind views
        adminEmail = findViewById(R.id.adminEmail);
        adminPassword = findViewById(R.id.adminPassword);
        adminLoginButton = findViewById(R.id.adminLoginButton);
        backToUserLogin = findViewById(R.id.backToUserLogin);

        // 🟣 Login Button Click
        adminLoginButton.setOnClickListener(v -> {
            String email = adminEmail.getText().toString().trim();
            String password = adminPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // ✅ Check against fixed admin credentials
            if (email.equals(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
                Toast.makeText(this, "Welcome Admin!", Toast.LENGTH_SHORT).show();

                // Go to Admin Dashboard
                Intent intent = new Intent(AdminLoginActivity.this, AdminActivity.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Invalid Admin Credentials!", Toast.LENGTH_SHORT).show();
            }
        });

        // 🔙 Back to user login
        backToUserLogin.setOnClickListener(v -> {
            Intent intent = new Intent(AdminLoginActivity.this, AdminLoginActivity.class);
            startActivity(intent);
            finish();
        });
    }
}