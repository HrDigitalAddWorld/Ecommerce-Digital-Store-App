package com.example.ecommerce

import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.motion.widget.MotionLayout

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // MotionLayout
        val motionLayout = findViewById<MotionLayout>(R.id.motionLayout)

        // Toggle button to switch sign-in / sign-up
        val btnToggle = findViewById<Button>(R.id.btnToggle)
        btnToggle.setOnClickListener {
            if (motionLayout.progress == 0f) {
                motionLayout.transitionToEnd()
            } else {
                motionLayout.transitionToStart()
            }
        }

        // Sign In / Sign Up buttons
        val btnSignIn = findViewById<Button>(R.id.btnSignIn)
        val btnSignUp = findViewById<Button>(R.id.btnSignUp)

        btnSignIn.setOnClickListener {
            Toast.makeText(this, "Sign In clicked", Toast.LENGTH_SHORT).show()
            // TODO: Add real sign-in logic here
        }

        btnSignUp.setOnClickListener {
            Toast.makeText(this, "Sign Up clicked", Toast.LENGTH_SHORT).show()
            // TODO: Add real sign-up logic here
        }

        // Social buttons
        val btnFacebook = findViewById<ImageButton>(R.id.btnFacebook)
        val btnGoogle = findViewById<ImageButton>(R.id.btnGoogle)
        val btnLinkedIn = findViewById<ImageButton>(R.id.btnLinkedIn)

        btnFacebook.setOnClickListener {
            Toast.makeText(this, "Facebook login clicked", Toast.LENGTH_SHORT).show()
        }

        btnGoogle.setOnClickListener {
            Toast.makeText(this, "Google login clicked", Toast.LENGTH_SHORT).show()
        }

        btnLinkedIn.setOnClickListener {
            Toast.makeText(this, "LinkedIn login clicked", Toast.LENGTH_SHORT).show()
        }
    }
}
