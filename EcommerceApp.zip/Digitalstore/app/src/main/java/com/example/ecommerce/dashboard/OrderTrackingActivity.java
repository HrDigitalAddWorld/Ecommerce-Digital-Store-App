package com.example.ecommerce.dashboard;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.adapters.TrackingAdapter;
import com.example.ecommerce.dashboard.models.TrackingStep;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OrderTrackingActivity extends AppCompatActivity {

    private TextView tvOrderId;
    private RecyclerView recyclerView;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tracking);

        tvOrderId = findViewById(R.id.tvOrderId);
        recyclerView = findViewById(R.id.trackingRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();

        String orderId = getIntent().getStringExtra("orderId");
        tvOrderId.setText("Order ID: " + orderId);

        fetchOrderTracking(orderId);
    }

    private void fetchOrderTracking(String orderId) {
        db.collection("orders").document(orderId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        List<TrackingStep> steps = new ArrayList<>();

                        boolean orderPlaced = documentSnapshot.getBoolean("orderPlaced") != null
                                && documentSnapshot.getBoolean("orderPlaced");
                        boolean shipped = documentSnapshot.getBoolean("shipped") != null
                                && documentSnapshot.getBoolean("shipped");
                        boolean outForDelivery = documentSnapshot.getBoolean("outForDelivery") != null
                                && documentSnapshot.getBoolean("outForDelivery");
                        boolean delivered = documentSnapshot.getBoolean("delivered") != null
                                && documentSnapshot.getBoolean("delivered");

                        Map<String, Object> dates = (Map<String, Object>) documentSnapshot.get("dates");

                        steps.add(new TrackingStep("Order Placed", orderPlaced, dates != null ? (String) dates.get("orderPlaced") : ""));
                        steps.add(new TrackingStep("Shipped", shipped, dates != null ? (String) dates.get("shipped") : ""));
                        steps.add(new TrackingStep("Out for Delivery", outForDelivery, dates != null ? (String) dates.get("outForDelivery") : ""));
                        steps.add(new TrackingStep("Delivered", delivered, dates != null ? (String) dates.get("delivered") : ""));

                        TrackingAdapter adapter = new TrackingAdapter(steps);
                        recyclerView.setAdapter(adapter);

                    } else {
                        Toast.makeText(this, "Order not found", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to fetch tracking: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }
}
