package com.example.ecommerce.ui.wishlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.data.db.AppDatabase;
import com.example.ecommerce.data.db.WishlistItem;
import com.example.ecommerce.data.db.CartItem;

import java.util.List;

public class WishlistAdapter extends RecyclerView.Adapter<WishlistAdapter.WishlistViewHolder> {

    private Context context;
    private List<WishlistItem> wishlistItems;

    public WishlistAdapter(Context context, List<WishlistItem> wishlistItems) {
        this.context = context;
        this.wishlistItems = wishlistItems;
    }

    @NonNull
    @Override
    public WishlistViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_wishlist, parent, false);
        return new WishlistViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WishlistViewHolder holder, int position) {
        WishlistItem item = wishlistItems.get(position);

        holder.tvName.setText(item.getName());
        holder.tvPrice.setText("₹ " + item.getPrice());

        // Remove from wishlist
        holder.btnRemove.setOnClickListener(v -> {
            AppDatabase.getInstance(context).wishlistDao().deleteWishlistItem(item);
            wishlistItems.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, wishlistItems.size());
        });

        // Move to cart
        holder.btnMoveToCart.setOnClickListener(v -> {
            CartItem cartItem = new CartItem(
                    item.getName(),
                    1,
                    item.getPrice()
            );

            AppDatabase.getInstance(context).cartDao().insertCartItem(cartItem);

            // Remove from wishlist after moving
            AppDatabase.getInstance(context).wishlistDao().deleteWishlistItem(item);
            wishlistItems.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, wishlistItems.size());

            Toast.makeText(context, item.getName() + " moved to cart", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public int getItemCount() {
        return wishlistItems.size();
    }

    public static class WishlistViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvPrice;
        ImageButton btnRemove;
        Button btnMoveToCart;

        public WishlistViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvWishlistName);
            tvPrice = itemView.findViewById(R.id.tvWishlistPrice);
            btnRemove = itemView.findViewById(R.id.btnRemoveWishlist);
            btnMoveToCart = itemView.findViewById(R.id.btnMoveToCart);
        }
    }
}
