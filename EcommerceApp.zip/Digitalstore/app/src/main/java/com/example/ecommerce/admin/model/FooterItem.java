package com.example.ecommerce.admin.model;

public class FooterItem {
    private String id;       // Firestore document ID
    private String title;
    private String link;

    public FooterItem() {
        // Required empty constructor for Firestore
    }

    public FooterItem(String title, String link) {
        this.title = title;
        this.link = link;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getLink() { return link; }
    public void setLink(String link) { this.link = link; }
}