package com.example.ecommerce.admin;

import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;

import java.io.File;
import java.util.List;

public class SlideAdapter extends RecyclerView.Adapter<SlideAdapter.SlideViewHolder> {

    private Context context;
    private List<Slide> slideList;
    private SlideActions actions;

    public interface SlideActions {
        void deleteSlide(Slide slide);
        void editSlide(Slide slide);
    }

    public SlideAdapter(Context context, List<Slide> slideList, SlideActions actions) {
        this.context = context;
        this.slideList = slideList;
        this.actions = actions;
    }

    @NonNull
    @Override
    public SlideViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_slide, parent, false);
        return new SlideViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SlideViewHolder holder, int position) {
        Slide slide = slideList.get(position);

        // Load image from internal storage
        File imgFile = new File(slide.getImagePath());
        if (imgFile.exists()) {
            holder.ivSlide.setImageBitmap(BitmapFactory.decodeFile(imgFile.getAbsolutePath()));
        }

        holder.tvDescription.setText(slide.getDescription());

        holder.ivDelete.setOnClickListener(v -> actions.deleteSlide(slide));
        holder.ivEdit.setOnClickListener(v -> actions.editSlide(slide));
    }

    @Override
    public int getItemCount() {
        return slideList.size();
    }

    static class SlideViewHolder extends RecyclerView.ViewHolder {
        ImageView ivSlide, ivDelete, ivEdit;
        TextView tvDescription;

        public SlideViewHolder(@NonNull View itemView) {
            super(itemView);
            ivSlide = itemView.findViewById(R.id.ivSlide);
            ivDelete = itemView.findViewById(R.id.ivDelete);
            ivEdit = itemView.findViewById(R.id.ivEdit);
            tvDescription = itemView.findViewById(R.id.tvDescription);
        }
    }
}
