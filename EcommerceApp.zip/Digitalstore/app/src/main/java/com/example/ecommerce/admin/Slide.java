package com.example.ecommerce.admin;

import java.util.HashMap;
import java.util.Map;

public class Slide {

    private String id;
    private String imagePath;
    private String description;
    private long createdAt;

    // Default constructor required for Firestore
    public Slide() {}

    public Slide(String id, String imagePath, String description, long createdAt) {
        this.id = id;
        this.imagePath = imagePath;
        this.description = description;
        this.createdAt = createdAt;
    }

    // Getters & Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public long getCreatedAt() { return createdAt; }
    public void setCreatedAt(long createdAt) { this.createdAt = createdAt; }

    // Convert to Map for Firestore
    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        map.put("imagePath", imagePath);
        map.put("description", description);
        map.put("createdAt", createdAt);
        return map;
    }
}
