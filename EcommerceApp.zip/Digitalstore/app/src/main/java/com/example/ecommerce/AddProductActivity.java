package com.example.ecommerce;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

public class AddProductActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1001;

    private EditText etProductName, etProductDescription, etProductPrice, etProductQuantity;
    private Button btnAddProduct, btnChooseImage;
    private ImageView ivProductImage;
    private Uri selectedImageUri;

    private FirebaseAuth auth;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product); // Use the same theme as login

        // Firebase instances
        auth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        // Bind views
        etProductName = findViewById(R.id.etProductName);
        etProductDescription = findViewById(R.id.etProductDescription);
        etProductPrice = findViewById(R.id.etProductPrice);
        etProductQuantity = findViewById(R.id.etProductQuantity);
        btnAddProduct = findViewById(R.id.btnAddProduct);
        btnChooseImage = findViewById(R.id.btnChooseImage);
        ivProductImage = findViewById(R.id.ivProductImage);

        // Pick image
        btnChooseImage.setOnClickListener(v -> openImageChooser());

        // Add product
        btnAddProduct.setOnClickListener(v -> addProduct());
    }

    // Open gallery to choose image
    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Product Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            ivProductImage.setImageURI(selectedImageUri);
        }
    }

    // Validate inputs and save product
    private void addProduct() {
        String name = etProductName.getText().toString().trim();
        String description = etProductDescription.getText().toString().trim();
        String priceStr = etProductPrice.getText().toString().trim();
        String quantityStr = etProductQuantity.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(description)
                || TextUtils.isEmpty(priceStr) || TextUtils.isEmpty(quantityStr)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (selectedImageUri == null) {
            Toast.makeText(this, "Please select a product image", Toast.LENGTH_SHORT).show();
            return;
        }

        double price;
        int quantity;
        try {
            price = Double.parseDouble(priceStr);
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid price or quantity", Toast.LENGTH_SHORT).show();
            return;
        }

        String merchantUid = auth.getCurrentUser().getUid();
        String productId = firestore.collection("products").document().getId();

        // Save image locally
        String localImagePath = saveImageToInternalStorage(selectedImageUri, productId);
        if (localImagePath == null) {
            Toast.makeText(this, "Failed to save image locally", Toast.LENGTH_SHORT).show();
            return;
        }

        // Prepare product data
        Map<String, Object> productData = new HashMap<>();
        productData.put("productName", name);
        productData.put("description", description);
        productData.put("price", price);
        productData.put("quantity", quantity);
        productData.put("merchantUid", merchantUid);
        productData.put("imagePath", localImagePath);
        productData.put("createdAt", System.currentTimeMillis());

        firestore.collection("products").document(productId)
                .set(productData)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Product added successfully!", Toast.LENGTH_SHORT).show();
                    resetForm();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Failed to add product: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    // Save image in internal storage
    private String saveImageToInternalStorage(Uri uri, String productId) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            String filename = "product_" + productId + ".jpg";
            File file = new File(getFilesDir(), filename);
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
            return file.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Reset form
    private void resetForm() {
        etProductName.setText("");
        etProductDescription.setText("");
        etProductPrice.setText("");
        etProductQuantity.setText("");
        ivProductImage.setImageResource(0);
        selectedImageUri = null;
    }
}
