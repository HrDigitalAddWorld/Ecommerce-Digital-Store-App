package com.example.ecommerce;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import com.example.ecommerce.ui.auth.LoginActivity;


public class LandingActivity extends AppCompatActivity {

    LinearLayout productContainer;
    Button btnLoginRegister;
    ImageButton btnCart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing);

        productContainer = findViewById(R.id.productContainer);
        btnLoginRegister = findViewById(R.id.btnLoginRegister);
        //btnCart = findViewById(R.id.btnCart);

        // Show login button, hide cart for now
        btnLoginRegister.setVisibility(View.VISIBLE);
        btnCart.setVisibility(View.GONE);

        btnLoginRegister.setOnClickListener(v ->
                startActivity(new Intent(LandingActivity.this, LoginActivity.class))
        );

        // Add static sample products
        addSampleProducts();
    }

    private void addSampleProducts() {
        String[][] products = {
                {"Smartphone", "placeholder_smartphone", "15000", "Merchant A"},
                {"T-Shirt", "placeholder_tshirt", "500", "Merchant B"},
                {"Book", "placeholder_book", "300", "Merchant C"}
        };

        LayoutInflater inflater = LayoutInflater.from(this);

        for (String[] p : products) {
            View productCard = inflater.inflate(R.layout.product_card, productContainer, false);

            ImageView imgProduct = productCard.findViewById(R.id.imgProduct);
            TextView tvName = productCard.findViewById(R.id.tvProductName);
            TextView tvPrice = productCard.findViewById(R.id.tvProductPrice);
            TextView tvMerchant = productCard.findViewById(R.id.tvMerchantName);

            tvName.setText(p[0]);
            tvPrice.setText("₹" + p[2]);
            tvMerchant.setText("By: " + p[3]);

            // Set drawable resource as placeholder image
            int resId = getResources().getIdentifier(p[1], "drawable", getPackageName());
            imgProduct.setImageResource(resId);

            productContainer.addView(productCard);
        }
    }
}
