package com.example.ecommerce.data.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface OrderDetailDao {

    @Insert
    void insertOrderDetail(OrderDetail detail);

    @Query("SELECT * FROM order_details WHERE orderId = :orderId")
    List<OrderDetail> getOrderDetailsForOrder(int orderId);
}
