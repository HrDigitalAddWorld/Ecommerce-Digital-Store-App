package com.example.ecommerce.admin.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.example.ecommerce.admin.model.Testimonial;
import com.example.ecommerce.R;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TestimonialAdapter extends RecyclerView.Adapter<TestimonialAdapter.TestimonialViewHolder> {

    private List<Testimonial> testimonials;
    private Context context;

    public TestimonialAdapter(List<Testimonial> testimonials, Context context) {
        this.testimonials = testimonials;
        this.context = context;
    }

    @NonNull
    @Override
    public TestimonialViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_testimonial, parent, false);
        return new TestimonialViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TestimonialViewHolder holder, int position) {
        Testimonial t = testimonials.get(position);
        holder.userName.setText(t.getUserName());
        holder.message.setText(t.getMessage());
    }

    @Override
    public int getItemCount() {
        return testimonials.size();
    }

    static class TestimonialViewHolder extends RecyclerView.ViewHolder {
        TextView userName, message;

        public TestimonialViewHolder(@NonNull View itemView) {
            super(itemView);
            userName = itemView.findViewById(R.id.tvUserName);
            message = itemView.findViewById(R.id.tvMessage);
        }
    }
}