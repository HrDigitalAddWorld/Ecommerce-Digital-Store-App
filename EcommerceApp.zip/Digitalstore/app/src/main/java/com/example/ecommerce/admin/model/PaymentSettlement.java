package com.example.ecommerce.admin.model;

public class PaymentSettlement {
    private String settlementId;
    private String sellerName;
    private String amount;
    private String date;

    public PaymentSettlement() {
        // Default constructor required for Firebase
    }

    public PaymentSettlement(String settlementId, String sellerName, String amount, String date) {
        this.settlementId = settlementId;
        this.sellerName = sellerName;
        this.amount = amount;
        this.date = date;
    }

    public String getSettlementId() {
        return settlementId;
    }

    public void setSettlementId(String settlementId) {
        this.settlementId = settlementId;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}