package com.example.ecommerce.admin.Adapter;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.ecommerce.admin.model.Gadget;

import com.example.ecommerce.R;

import java.util.List;

public class GadgetAdapter extends RecyclerView.Adapter<GadgetAdapter.GadgetViewHolder> {

    private List<Gadget> gadgets;
    private Context context;

    public GadgetAdapter(List<Gadget> gadgets, Context context) {
        this.gadgets = gadgets;
        this.context = context;
    }

    @NonNull
    @Override
    public GadgetViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_gadget, parent, false);
        return new GadgetViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GadgetViewHolder holder, int position) {
        Gadget g = gadgets.get(position);
        holder.name.setText(g.getName());

        // Show price properly with currency
        holder.price.setText("₹" + (g.getPrice() != null ? String.format("%.2f", g.getPrice()) : "0.00"));

        // Show image using URI
        if (g.getImageUrl() != null && !g.getImageUrl().isEmpty()) {
            holder.image.setImageURI(Uri.parse(g.getImageUrl()));
        } else {
            holder.image.setImageResource(R.drawable.ic_placeholder);
        }
    }

    @Override
    public int getItemCount() {
        return gadgets.size();
    }

    static class GadgetViewHolder extends RecyclerView.ViewHolder {
        TextView name, price;
        ImageView image;

        public GadgetViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.tvGadgetName);
            price = itemView.findViewById(R.id.tvGadgetPrice);
            image = itemView.findViewById(R.id.ivGadgetImage);
        }
    }
}