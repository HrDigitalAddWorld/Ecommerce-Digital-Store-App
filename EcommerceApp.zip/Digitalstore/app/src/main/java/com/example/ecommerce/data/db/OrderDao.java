package com.example.ecommerce.data.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Delete;
import androidx.room.Query;

import com.example.ecommerce.data.db.orderr;

import java.util.List;

@Dao
public interface OrderDao {

    @Insert
    long insertOrder(orderr order);

    @Query("SELECT * FROM orders WHERE id = :orderId LIMIT 1")
    orderr getOrderById(int orderId);

    @Query("SELECT * FROM orders")
    List<orderr> getAllOrders();

    @Delete
    void deleteOrder(orderr order);
}
