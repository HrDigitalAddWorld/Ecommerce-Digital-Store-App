package com.example.ecommerce.data.db;
import android.content.Context;
import androidx.room.Room;
import androidx.room.Database;
import androidx.room.RoomDatabase;

import com.example.ecommerce.data.model.Product;
import com.example.ecommerce.data.model.User;


// Import DAOs

@Database(entities = {CartItem.class, User.class,OrderItem.class ,WishlistItem.class, OrderDetail.class,Review.class,OrderProduct.class,Product.class, orderr.class }, version = 2) // bump version
public abstract class AppDatabase extends RoomDatabase {

    private static AppDatabase instance;

    public abstract CartDao cartDao();
    public abstract UserDao userDao();
    public abstract OrderDao orderDao();
    public abstract WishlistDao wishlistDao();
    public abstract OrderDetailDao orderDetailDao();
    public abstract OrderProductDao orderProductDao();
    public abstract ReviewDao reviewDao();

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "ecommerce_db")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }
}
