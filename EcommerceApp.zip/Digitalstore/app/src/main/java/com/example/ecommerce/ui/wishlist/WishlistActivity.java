package com.example.ecommerce.ui.wishlist;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.ecommerce.R;
import com.example.ecommerce.data.db.AppDatabase;
import com.example.ecommerce.data.db.WishlistItem;
import java.util.List;

public class WishlistActivity extends AppCompatActivity {

    RecyclerView recyclerWishlist;
    WishlistAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);

        recyclerWishlist = findViewById(R.id.recyclerWishlist);
        recyclerWishlist.setLayoutManager(new LinearLayoutManager(this));

        List<WishlistItem> wishlistItems = AppDatabase.getInstance(this)
                .wishlistDao()
                .getAllWishlistItems();

        adapter = new WishlistAdapter(this ,wishlistItems);
        recyclerWishlist.setAdapter(adapter);
    }
}
