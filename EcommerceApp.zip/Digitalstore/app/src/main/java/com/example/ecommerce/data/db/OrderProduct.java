package com.example.ecommerce.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "order_products")
public class OrderProduct {

    @PrimaryKey(autoGenerate = true)
    private int orderId;
    private String productName;
    private int quantity;
    private double price;

    // Constructor
    public OrderProduct(int orderId, String productName, int quantity, double price) {
        this.orderId = orderId;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters
    public int getOrderId() {
        return orderId;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }
}

