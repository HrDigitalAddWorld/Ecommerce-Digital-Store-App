package com.example.ecommerce.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.adapters.BannerAdapter;
import com.example.ecommerce.dashboard.adapters.CategoryAdapter;
import com.example.ecommerce.dashboard.adapters.ProductAdapter;
import com.example.ecommerce.dashboard.models.Category;
import com.example.ecommerce.dashboard.models.Product;
import com.example.ecommerce.ui.auth.LoginActivity;
import com.example.ecommerce.ChatbotActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {

    private ImageView cartButton, loginIcon, ordersIcon;
    private ViewPager2 bannerViewPager;
    private RecyclerView categoryRecycler, dealsRecycler, recommendedRecycler;
    private FloatingActionButton btnChatbot; // 👈 added

    private BannerAdapter bannerAdapter;
    private CategoryAdapter categoryAdapter;
    private ProductAdapter dealsAdapter, recommendedAdapter;

    private List<String> bannerList;
    private List<Category> categoryList;
    private List<Product> dealsList, recommendedList;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Firebase instances
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Views
        cartButton = findViewById(R.id.cartButton);
        loginIcon = findViewById(R.id.loginIcon);
        ordersIcon = findViewById(R.id.ordersIcon);
        bannerViewPager = findViewById(R.id.bannerViewPager);
        categoryRecycler = findViewById(R.id.categoryRecycler);
        dealsRecycler = findViewById(R.id.dealsRecycler);
        recommendedRecycler = findViewById(R.id.recommendedRecycler);
        btnChatbot = findViewById(R.id.btnChatbot); // 👈 added

        setupUserFlow();
        setupBanners();
        setupCategories();
        fetchDealsFromFirestore();
        fetchRecommendedFromFirestore();

        // 👇 Chatbot Button Click Listener
        btnChatbot.setOnClickListener(v -> {
            Intent intent = new Intent(DashboardActivity.this, ChatbotActivity.class);
            startActivity(intent);
        });
    }

    private void setupUserFlow() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        boolean isGuest = getIntent().getBooleanExtra("IS_GUEST", false);

        if (isGuest || currentUser == null) {
            cartButton.setVisibility(ImageView.GONE);
            ordersIcon.setVisibility(ImageView.GONE);
            loginIcon.setVisibility(ImageView.VISIBLE);

            loginIcon.setOnClickListener(v ->
                    startActivity(new Intent(DashboardActivity.this, LoginActivity.class))
            );
        } else {
            cartButton.setVisibility(ImageView.VISIBLE);
            ordersIcon.setVisibility(ImageView.VISIBLE);
            loginIcon.setVisibility(ImageView.GONE);

            cartButton.setOnClickListener(v ->
                    startActivity(new Intent(DashboardActivity.this, CartActivity.class))
            );

            ordersIcon.setOnClickListener(v ->
                    startActivity(new Intent(DashboardActivity.this, UserOrdersActivity.class))
            );
        }
    }

    private void setupBanners() {
        bannerList = new ArrayList<>();
        bannerAdapter = new BannerAdapter(this, bannerList);
        bannerViewPager.setAdapter(bannerAdapter);

        db.collection("slides")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    bannerList.clear();
                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        String imageUrl = doc.getString("imageUrl");
                        if (imageUrl != null) bannerList.add(imageUrl);
                    }
                    bannerAdapter.notifyDataSetChanged();
                    Log.d("Dashboard", "Fetched " + bannerList.size() + " banners.");
                })
                .addOnFailureListener(e -> Log.e("Dashboard", "Failed to fetch banners", e));
    }

    private void setupCategories() {
        categoryList = new ArrayList<>();
        categoryList.add(new Category("Electronic", "ic_electronics", true));
        categoryList.add(new Category("Fashion", "ic_fashion", true));
        categoryList.add(new Category("Grocery", "ic_grocery", true));
        categoryList.add(new Category("Beauty & Personal Care", "ic_beauty", true));
        categoryList.add(new Category("Sports Hub", "ic_sports", true));
        categoryList.add(new Category("Home Appliance", "ic_home_appliances", true));

        categoryAdapter = new CategoryAdapter(this, categoryList);
        categoryRecycler.setAdapter(categoryAdapter);
        categoryRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
    }

    private void fetchDealsFromFirestore() {
        dealsList = new ArrayList<>();
        dealsAdapter = new ProductAdapter(this, dealsList);
        dealsRecycler.setAdapter(dealsAdapter);
        dealsRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        db.collection("products")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        dealsList.clear();
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            String id = doc.getId();
                            String name = doc.getString("productName");
                            String image = doc.getString("imagePath");
                            String desc = doc.getString("description");
                            String qty = String.valueOf(doc.get("quantity"));
                            Object priceObj = doc.get("price");
                            String price = priceObj != null ? String.valueOf(priceObj) : "0";
                            String merchantUid = doc.getString("merchantUid");

                            dealsList.add(new Product(id, name, image, price, desc, qty, merchantUid));
                        }
                        dealsAdapter.notifyDataSetChanged();
                        Log.d("Dashboard", "Fetched " + dealsList.size() + " deals.");
                    } else {
                        Log.e("Dashboard", "Failed to fetch deals", task.getException());
                    }
                });
    }

    private void fetchRecommendedFromFirestore() {
        recommendedList = new ArrayList<>();
        recommendedAdapter = new ProductAdapter(this, recommendedList);
        recommendedRecycler.setAdapter(recommendedAdapter);
        recommendedRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));

        db.collection("recommended")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        recommendedList.clear();
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            String id = doc.getId();
                            String name = doc.getString("productName");
                            String image = doc.getString("imagePath");
                            String desc = doc.getString("description") != null ? doc.getString("description") : "";
                            Object priceObj = doc.get("price");
                            String price = priceObj != null ? String.valueOf(priceObj) : "0";
                            Object qtyObj = doc.get("quantity");
                            String qty = qtyObj != null ? String.valueOf(qtyObj) : "0";
                            String merchantUid = doc.getString("merchantUid");

                            recommendedList.add(new Product(id, name, image, price, desc, qty, merchantUid));
                        }
                        recommendedAdapter.notifyDataSetChanged();
                        Log.d("Dashboard", "Fetched " + recommendedList.size() + " recommended products.");
                    } else {
                        Log.e("Dashboard", "Failed to fetch recommended", task.getException());
                    }
                });
    }
}
