package com.example.ecommerce.admin.model;

public class Testimonial {
    private String userName;
    private String message;

    public Testimonial() {} // Firestore requires empty constructor

    public Testimonial(String userName, String message) {
        this.userName = userName;
        this.message = message;
    }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}