package com.example.ecommerce.admin;

import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.example.ecommerce.admin.model.Payment;
import com.example.ecommerce.admin.Adapter.PaymentAdapter;
import com.example.ecommerce.R;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;

public class UserPaymentsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Payment> paymentList;
    private PaymentAdapter paymentAdapter;

    private FirebaseFirestore db;
    private CollectionReference paymentRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_payments);

        recyclerView = findViewById(R.id.recyclerPayments);
        db = FirebaseFirestore.getInstance();
        paymentRef = db.collection("payments");

        paymentList = new ArrayList<>();
        paymentAdapter = new PaymentAdapter(paymentList, paymentRef, new PaymentAdapter.OnItemClickListener() {
            @Override
            public void onEdit(Payment payment) {
                showPaymentDialog(payment, true);
            }

            @Override
            public void onDelete(Payment payment) {
                if (payment.getPaymentId() != null) {
                    paymentRef.document(payment.getPaymentId()).delete()
                            .addOnSuccessListener(aVoid ->
                                    Toast.makeText(UserPaymentsActivity.this, "Payment Deleted", Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e ->
                                    Toast.makeText(UserPaymentsActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(paymentAdapter);

        loadPayments();

        findViewById(R.id.btnAddPayment).setOnClickListener(v -> showPaymentDialog(null, false));
    }

    private void loadPayments() {
        paymentRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Toast.makeText(UserPaymentsActivity.this, "Error loading payments!", Toast.LENGTH_SHORT).show();
                    return;
                }

                paymentList.clear();
                for (DocumentSnapshot snapshot : value.getDocuments()) {
                    Payment payment = snapshot.toObject(Payment.class);
                    if (payment != null) {
                        payment.setPaymentId(snapshot.getId());
                        paymentList.add(payment);
                    }
                }
                paymentAdapter.notifyDataSetChanged();
            }
        });
    }

    private void showPaymentDialog(@Nullable Payment payment, boolean isEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isEdit ? "Edit Payment" : "Add Payment");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20,20,20,20);

        final EditText edtUser = new EditText(this);
        edtUser.setHint("User Name");
        if(isEdit) edtUser.setText(payment.getUserName());
        layout.addView(edtUser);

        final EditText edtAmount = new EditText(this);
        edtAmount.setHint("Amount");
        edtAmount.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if(isEdit) edtAmount.setText(String.valueOf(payment.getAmount()));
        layout.addView(edtAmount);

        final EditText edtMethod = new EditText(this);
        edtMethod.setHint("Payment Method");
        if(isEdit) edtMethod.setText(payment.getMethod());
        layout.addView(edtMethod);

        final EditText edtStatus = new EditText(this);
        edtStatus.setHint("Status");
        if(isEdit) edtStatus.setText(payment.getStatus());
        layout.addView(edtStatus);

        builder.setView(layout);

        builder.setPositiveButton(isEdit ? "Update" : "Add", (dialog, which) -> {
            String userName = edtUser.getText().toString().trim();
            String amountStr = edtAmount.getText().toString().trim();
            String method = edtMethod.getText().toString().trim();
            String status = edtStatus.getText().toString().trim();

            if(!userName.isEmpty() && !amountStr.isEmpty() && !method.isEmpty() && !status.isEmpty()){
                double amount = Double.parseDouble(amountStr);
                String id = isEdit ? payment.getPaymentId() : paymentRef.document().getId();
                Payment newPayment = new Payment(id, userName, amount, method, status);
                paymentRef.document(id).set(newPayment)
                        .addOnSuccessListener(aVoid ->
                                Toast.makeText(UserPaymentsActivity.this, isEdit ? "Payment Updated" : "Payment Added", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e ->
                                Toast.makeText(UserPaymentsActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel",(dialog,which)-> dialog.dismiss());
        builder.show();
    }
}