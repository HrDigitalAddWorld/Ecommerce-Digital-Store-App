package com.example.ecommerce;

public class Product {
    private String id;
    private String productName;
    private String description;
    private double price;
    private int quantity;
    private String merchantUid;
    private String imagePath;

    // Empty constructor required by Firestore
    public Product() {}

    // Getters
    public String getId() { return id; }
    public String getProductName() { return productName; }
    public String getDescription() { return description; }
    public double getPrice() { return price; }
    public int getQuantity() { return quantity; }
    public String getMerchantUid() { return merchantUid; }
    public String getImagePath() { return imagePath; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setProductName(String productName) { this.productName = productName; }
    public void setDescription(String description) { this.description = description; }
    public void setPrice(double price) { this.price = price; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setMerchantUid(String merchantUid) { this.merchantUid = merchantUid; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }
}
