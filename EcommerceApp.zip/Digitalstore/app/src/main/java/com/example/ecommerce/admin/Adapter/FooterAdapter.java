package com.example.ecommerce.admin.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.admin.model.FooterItem;
import com.example.ecommerce.admin.Adapter.FooterAdapter;
import com.example.ecommerce.R;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class FooterAdapter extends RecyclerView.Adapter<FooterAdapter.FooterViewHolder> {

    private List<FooterItem> footerList;
    private Context context;

    public FooterAdapter(List<FooterItem> footerList, Context context) {
        this.footerList = footerList;
        this.context = context;
    }

    @NonNull
    @Override
    public FooterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_footer, parent, false);
        return new FooterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FooterViewHolder holder, int position) {
        FooterItem item = footerList.get(position);

        holder.txtTitle.setText(item.getTitle());
        holder.txtLink.setText(item.getLink());

        holder.btnDelete.setOnClickListener(v -> {
            FirebaseFirestore.getInstance().collection("footers")
                    .document(item.getId())
                    .delete()
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(context, "Footer deleted", Toast.LENGTH_SHORT).show();
                        footerList.remove(position);
                        notifyItemRemoved(position);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(context, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });
    }

    @Override
    public int getItemCount() {
        return footerList.size();
    }

    static class FooterViewHolder extends RecyclerView.ViewHolder {
        TextView txtTitle, txtLink;
        ImageButton btnDelete;

        public FooterViewHolder(@NonNull View itemView) {
            super(itemView);
            txtTitle = itemView.findViewById(R.id.txtFooterTitle);
            txtLink = itemView.findViewById(R.id.txtFooterLink);
            btnDelete = itemView.findViewById(R.id.btnDeleteFooter);
        }
    }
}