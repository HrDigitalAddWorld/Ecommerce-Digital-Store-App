package com.example.ecommerce.admin;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SlideManagementActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1001;

    private Button btnAddSlide;
    private RecyclerView recyclerViewSlides;
    private List<Slide> slideList;
    private SlideAdapter slideAdapter;

    private FirebaseFirestore firestore;
    private Uri selectedImageUri;
    private String newSlideDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slide_management);

        btnAddSlide = findViewById(R.id.btnAddSlide);
        recyclerViewSlides = findViewById(R.id.recyclerViewSlides);

        firestore = FirebaseFirestore.getInstance();
        slideList = new ArrayList<>();

        slideAdapter = new SlideAdapter(this, slideList, new SlideAdapter.SlideActions() {
            @Override
            public void deleteSlide(Slide slide) {
                removeSlide(slide);
            }

            @Override
            public void editSlide(Slide slide) {
                showDescriptionDialog(slide);
            }
        });

        recyclerViewSlides.setAdapter(slideAdapter);
        recyclerViewSlides.setLayoutManager(new LinearLayoutManager(this));

        btnAddSlide.setOnClickListener(v -> showAddSlideDialog());

        fetchSlides();
    }

    private void showAddSlideDialog() {
        // Ask for description first
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Slide Description");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        builder.setPositiveButton("Next", (dialog, which) -> {
            newSlideDescription = input.getText().toString().trim();
            openImageChooser();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    /** Open gallery to select slide image */
    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Slide Image"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            saveNewSlide();
        }
    }

    /** Save a new slide to Firestore */
    private void saveNewSlide() {
        if (selectedImageUri == null) return;

        String slideId = firestore.collection("slides").document().getId();
        String localImagePath = saveImageToInternalStorage(selectedImageUri, slideId);
        if (localImagePath == null) {
            Toast.makeText(this, "Failed to save image locally", Toast.LENGTH_SHORT).show();
            return;
        }

        Slide slide = new Slide(slideId, localImagePath, newSlideDescription, System.currentTimeMillis());
        firestore.collection("slides").document(slideId)
                .set(slide.toMap())
                .addOnSuccessListener(aVoid -> {
                    slideList.add(slide);
                    slideAdapter.notifyItemInserted(slideList.size() - 1);
                    Toast.makeText(this, "Slide added successfully!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to add slide: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    /** Save image in internal storage */
    private String saveImageToInternalStorage(Uri uri, String slideId) {
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uri);
            String filename = "slide_" + slideId + ".jpg";
            File file = new File(getFilesDir(), filename);
            FileOutputStream fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
            return file.getAbsolutePath();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    /** Fetch slides from Firestore */
    private void fetchSlides() {
        firestore.collection("slides")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        slideList.clear();
                        for (DocumentSnapshot doc : task.getResult().getDocuments()) {
                            Slide slide = new Slide(
                                    doc.getId(),
                                    doc.getString("imagePath"),
                                    doc.getString("description"),
                                    doc.getLong("createdAt") != null ? doc.getLong("createdAt") : System.currentTimeMillis()
                            );
                            slideList.add(slide);
                        }
                        slideAdapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(SlideManagementActivity.this, "Failed to fetch slides.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    /** Remove a slide */
    private void removeSlide(Slide slide) {
        firestore.collection("slides").document(slide.getId())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    slideList.remove(slide);
                    slideAdapter.notifyDataSetChanged();
                    Toast.makeText(this, "Slide deleted.", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to delete slide.", Toast.LENGTH_SHORT).show());
    }

    /** Edit slide description */
    private void showDescriptionDialog(Slide slide) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Description");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setText(slide.getDescription());
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            slide.setDescription(input.getText().toString().trim());
            firestore.collection("slides").document(slide.getId())
                    .set(slide.toMap())
                    .addOnSuccessListener(aVoid -> slideAdapter.notifyDataSetChanged())
                    .addOnFailureListener(e -> Toast.makeText(this, "Failed to update slide.", Toast.LENGTH_SHORT).show());
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }
}
