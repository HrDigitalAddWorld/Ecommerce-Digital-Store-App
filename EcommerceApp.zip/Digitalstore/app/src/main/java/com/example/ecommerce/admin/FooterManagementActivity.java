package com.example.ecommerce.admin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.ecommerce.admin.Adapter.FooterAdapter;
import com.example.ecommerce.admin.model.FooterItem;
import com.example.ecommerce.R;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class FooterManagementActivity extends AppCompatActivity {

    private EditText edtFooterTitle, edtFooterLink;
    private Button btnAddFooter;
    private RecyclerView recyclerView;

    private FooterAdapter adapter;
    private List<FooterItem> footerList;

    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_footer_management);

        edtFooterTitle = findViewById(R.id.edtFooterTitle);
        edtFooterLink = findViewById(R.id.edtFooterLink);
        btnAddFooter = findViewById(R.id.btnAddFooter);
        recyclerView = findViewById(R.id.recyclerViewFooter);

        db = FirebaseFirestore.getInstance();
        footerList = new ArrayList<>();
        adapter = new FooterAdapter(footerList, this);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        loadFooterItems();

        btnAddFooter.setOnClickListener(v -> {
            String title = edtFooterTitle.getText().toString().trim();
            String link = edtFooterLink.getText().toString().trim();

            if (title.isEmpty() || link.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            DocumentReference docRef = db.collection("footers").document();
            FooterItem item = new FooterItem(title, link);
            item.setId(docRef.getId());

            docRef.set(item)
                    .addOnSuccessListener(aVoid -> {
                        Toast.makeText(this, "Footer Added", Toast.LENGTH_SHORT).show();
                        edtFooterTitle.setText("");
                        edtFooterLink.setText("");
                        footerList.add(item);
                        adapter.notifyItemInserted(footerList.size() - 1);
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });
    }

    private void loadFooterItems() {
        db.collection("footers").get()
                .addOnSuccessListener(querySnapshot -> {
                    footerList.clear();
                    for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                        FooterItem item = doc.toObject(FooterItem.class);
                        if (item != null) {
                            item.setId(doc.getId()); // store document id
                            footerList.add(item);
                        }
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}