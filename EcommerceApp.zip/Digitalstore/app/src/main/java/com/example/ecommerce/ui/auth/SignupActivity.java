package com.example.ecommerce.ui.auth;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;

public class SignupActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setGravity(Gravity.CENTER);
        layout.setBackgroundColor(0xFFEFEFEF);
        TextView textView = new TextView(this);
        textView.setText("Signup Activity");
        textView.setTextSize(24);
        layout.addView(textView);
        setContentView(layout);
    }
}
