package com.example.ecommerce.data.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface ReviewDao {

    @Insert
    long insertReview(Review review);

    @Query("SELECT * FROM reviews WHERE productId = :productId ORDER BY id DESC")
    List<Review> getReviewsForProduct(int productId);
}
