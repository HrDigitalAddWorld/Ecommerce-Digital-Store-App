package com.example.ecommerce;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MerchantViewOrdersActivity extends AppCompatActivity {

    private RecyclerView ordersRecycler;
    private MerchantOrderAdapter orderAdapter;
    private List<MerchantOrder> orderList;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_orders);

        ordersRecycler = findViewById(R.id.ordersRecycler);
        ordersRecycler.setLayoutManager(new LinearLayoutManager(this));

        orderList = new ArrayList<>();
        orderAdapter = new MerchantOrderAdapter(this, orderList);
        ordersRecycler.setAdapter(orderAdapter);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        fetchMerchantOrders();
    }

    private void fetchMerchantOrders() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "Merchant not logged in!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String merchantId = currentUser.getUid();

        db.collection("orders")
                .whereArrayContains("merchantUid", merchantId) // only orders for this merchant
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        orderList.clear();
                        for (QueryDocumentSnapshot doc : task.getResult()) {

                            String orderId = doc.getString("orderId") != null ? doc.getString("orderId") : "-";

                            // Convert Firestore Timestamp to readable string
                            String orderDate = "N/A";
                            if (doc.get("orderDate") instanceof com.google.firebase.Timestamp) {
                                com.google.firebase.Timestamp timestamp = doc.getTimestamp("orderDate");
                                if (timestamp != null) {
                                    Date date = timestamp.toDate();
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault());
                                    orderDate = sdf.format(date);
                                }
                            }

                            String orderAmount = doc.get("grandTotal") != null ? String.valueOf(doc.get("grandTotal")) : "0";

                            // Fetch status map
                            Map<String, Boolean> statusMap = new HashMap<>();
                            Object statusObj = doc.get("status");
                            if (statusObj instanceof Map) {
                                Map<?, ?> rawMap = (Map<?, ?>) statusObj;
                                statusMap.put("shipped", rawMap.get("shipped") != null && (Boolean) rawMap.get("shipped"));
                                statusMap.put("outForDelivery", rawMap.get("outForDelivery") != null && (Boolean) rawMap.get("outForDelivery"));
                                statusMap.put("delivered", rawMap.get("delivered") != null && (Boolean) rawMap.get("delivered"));
                            } else {
                                statusMap.put("shipped", false);
                                statusMap.put("outForDelivery", false);
                                statusMap.put("delivered", false);
                            }

                            String docId = doc.getId();

                            orderList.add(new MerchantOrder(docId, orderId, orderDate, orderAmount, statusMap, merchantId));
                        }

                        orderAdapter.notifyDataSetChanged();
                        Log.d("MerchantViewOrders", "Fetched " + orderList.size() + " orders for merchant.");
                    } else {
                        Log.e("MerchantViewOrders", "Failed to fetch orders", task.getException());
                        Toast.makeText(this, "Failed to fetch orders", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
