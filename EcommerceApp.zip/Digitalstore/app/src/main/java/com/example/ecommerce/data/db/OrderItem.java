package com.example.ecommerce.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "order_items")
public class OrderItem {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String orderName;   // Example: "Order on Tue Sep 10 2025"
    public double totalAmount;

    public OrderItem(int id, String orderName, double totalAmount) {
        this.id = id;
        this.orderName = orderName;
        this.totalAmount = totalAmount;
    }
}
