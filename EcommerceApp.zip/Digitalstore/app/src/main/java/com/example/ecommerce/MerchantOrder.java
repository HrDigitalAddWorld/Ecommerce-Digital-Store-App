package com.example.ecommerce;

import java.util.HashMap;
import java.util.Map;

public class MerchantOrder {

    private String docId;
    private String orderId;
    private String orderDate;
    private String orderAmount;
    private Map<String, Boolean> status;
    private String merchantUid;

    public MerchantOrder() {
        this.status = new HashMap<>();
        this.status.put("shipped", false);
        this.status.put("outForDelivery", false);
        this.status.put("delivered", false);
    }

    public MerchantOrder(String docId, String orderId, String orderDate, String orderAmount, Map<String, Boolean> status, String merchantUid) {
        this.docId = docId;
        this.orderId = orderId;
        this.orderDate = orderDate;
        this.orderAmount = orderAmount;
        this.status = status != null ? status : new HashMap<>();
        this.merchantUid = merchantUid;

        if (!this.status.containsKey("shipped")) this.status.put("shipped", false);
        if (!this.status.containsKey("outForDelivery")) this.status.put("outForDelivery", false);
        if (!this.status.containsKey("delivered")) this.status.put("delivered", false);
    }

    // Getters and Setters
    public String getDocId() { return docId; }
    public void setDocId(String docId) { this.docId = docId; }

    public String getOrderId() { return orderId; }
    public void setOrderId(String orderId) { this.orderId = orderId; }

    public String getOrderDate() { return orderDate; }
    public void setOrderDate(String orderDate) { this.orderDate = orderDate; }

    public String getOrderAmount() { return orderAmount; }
    public void setOrderAmount(String orderAmount) { this.orderAmount = orderAmount; }

    public Map<String, Boolean> getStatus() { return status; }
    public void setStatus(Map<String, Boolean> status) { this.status = status; }

    public String getMerchantUid() { return merchantUid; }
    public void setMerchantUid(String merchantUid) { this.merchantUid = merchantUid; }
}
