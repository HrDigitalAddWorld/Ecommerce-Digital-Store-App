package com.example.ecommerce.dashboard.adapters;

import android.content.Context;
import android.widget.Button;
import android.widget.TextView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.models.CartItem;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private final Context context;
    private final List<CartItem> cartList;
    private final Runnable updateTotalCallback;

    private final FirebaseFirestore db;
    private final FirebaseAuth auth;

    public CartAdapter(Context context, List<CartItem> cartList, Runnable updateTotalCallback) {
        this.context = context;
        this.cartList = cartList;
        this.updateTotalCallback = updateTotalCallback;

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartList.get(position);

        holder.tvName.setText(item.getName());
        holder.tvPrice.setText("₹ " + item.getPrice());
        holder.tvQuantity.setText(String.valueOf(item.getQuantity()));

        String userId = auth.getCurrentUser() != null ? auth.getCurrentUser().getUid() : null;
        if (userId == null) return; // safety check

        // Increase quantity
        holder.btnIncrease.setOnClickListener(v -> {
            int newQty = item.getQuantity() + 1;
            item.setQuantity(newQty);
            notifyItemChanged(position);
            updateTotalCallback.run();

            // Update Firestore
            db.collection("users")
                    .document(userId)
                    .collection("cart")
                    .document(item.getProductId())
                    .update("quantity", newQty)
                    .addOnFailureListener(e ->
                            Toast.makeText(context, "Failed to update quantity", Toast.LENGTH_SHORT).show()
                    );
        });

        // Decrease quantity
        holder.btnDecrease.setOnClickListener(v -> {
            if (item.getQuantity() > 1) {
                int newQty = item.getQuantity() - 1;
                item.setQuantity(newQty);
                notifyItemChanged(position);
                updateTotalCallback.run();

                // Update Firestore
                db.collection("users")
                        .document(userId)
                        .collection("cart")
                        .document(item.getProductId())
                        .update("quantity", newQty)
                        .addOnFailureListener(e ->
                                Toast.makeText(context, "Failed to update quantity", Toast.LENGTH_SHORT).show()
                        );
            }
        });

        // Remove item
        holder.btnDelete.setOnClickListener(v -> {
            db.collection("users")
                    .document(userId)
                    .collection("cart")
                    .document(item.getProductId())
                    .delete()
                    .addOnSuccessListener(unused -> {
                        cartList.remove(position);
                        notifyItemRemoved(position);
                        updateTotalCallback.run();
                        Toast.makeText(context, "Item removed from cart", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(context, "Failed to remove item", Toast.LENGTH_SHORT).show()
                    );
        });
    }

    @Override
    public int getItemCount() {
        return cartList.size();
    }

    static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvPrice, tvQuantity;
        Button btnIncrease, btnDecrease, btnDelete;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvCartName);
            tvPrice = itemView.findViewById(R.id.tvCartPrice);
            tvQuantity = itemView.findViewById(R.id.tvCartQuantity);
            btnIncrease = itemView.findViewById(R.id.btnIncrease);
            btnDecrease = itemView.findViewById(R.id.btnDecrease);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
