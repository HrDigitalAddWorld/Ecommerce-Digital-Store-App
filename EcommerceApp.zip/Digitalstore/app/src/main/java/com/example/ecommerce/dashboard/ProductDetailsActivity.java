package com.example.ecommerce.dashboard;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.ecommerce.R;
import com.example.ecommerce.ui.auth.LoginActivity; // <-- import your login activity
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class ProductDetailsActivity extends AppCompatActivity {

    private ImageView productImage;
    private TextView productName, productDescription, productPrice, productQuantity, merchantName;
    private Button addToCartBtn, buyNowBtn;

    private FirebaseFirestore db;
    private FirebaseAuth auth;

    private String productId, name, imageUrl, description, price, quantity, merchantUid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);

        // Initialize Firebase
        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // Bind Views
        productImage = findViewById(R.id.productImage);
        productName = findViewById(R.id.productName);
        productDescription = findViewById(R.id.productDescription);
        productPrice = findViewById(R.id.productPrice);
        productQuantity = findViewById(R.id.productQuantity);
        merchantName = findViewById(R.id.merchantName);
        addToCartBtn = findViewById(R.id.addToCartBtn);
        buyNowBtn = findViewById(R.id.buyNowBtn);

        // Get product data from Intent
        productId = getIntent().getStringExtra("productId");
        name = getIntent().getStringExtra("name");
        imageUrl = getIntent().getStringExtra("imageUrl");
        description = getIntent().getStringExtra("description");
        price = getIntent().getStringExtra("price");
        quantity = getIntent().getStringExtra("quantity");
        merchantUid = getIntent().getStringExtra("merchantUid");

        // Set product data
        productName.setText(name != null ? name : "Unknown Product");
        productDescription.setText(description != null ? description : "No description available");
        productPrice.setText(price != null ? "₹" + price : "₹0");
        productQuantity.setText(quantity != null ? "Available: " + quantity : "Available: N/A");

        Glide.with(this)
                .load(imageUrl != null ? imageUrl : R.drawable.product_placeholder)
                .placeholder(R.drawable.product_placeholder)
                .into(productImage);

        fetchMerchantName();

        // Button listeners
        addToCartBtn.setOnClickListener(v -> handleAddToCart());
        buyNowBtn.setOnClickListener(v -> handleBuyNow());
    }

    private void fetchMerchantName() {
        if (merchantUid == null || merchantUid.isEmpty()) {
            merchantName.setText("Sold by: Unknown Store");
            return;
        }

        db.collection("merchants")
                .document(merchantUid)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String storeName = documentSnapshot.getString("storeName");
                        merchantName.setText("Sold by: " + (storeName != null ? storeName : "Unknown Store"));
                    } else {
                        merchantName.setText("Sold by: Unknown Store");
                    }
                })
                .addOnFailureListener(e -> merchantName.setText("Sold by: Unknown Store"));
    }

    private void handleAddToCart() {
        if (auth.getCurrentUser() == null) {
            // Guest user → force redirect to login
            Toast.makeText(this, "Please login to add items to cart", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ProductDetailsActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish(); // prevent coming back to this page as guest
            return;
        }

        // only logged-in users can proceed
        addToCart();
    }

    private void handleBuyNow() {
        if (auth.getCurrentUser() == null) {
            // Guest user → redirect to login
            Toast.makeText(this, "Please login to continue", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(ProductDetailsActivity.this, LoginActivity.class));
            return;
        }

        // Logged-in user → go to CartActivity directly (simulate buy now)
        Intent intent = new Intent(ProductDetailsActivity.this, CartActivity.class);
        startActivity(intent);
    }

    private void addToCart() {
        if (auth.getCurrentUser() == null) {
            // just in case (double security)
            Toast.makeText(this, "Login required", Toast.LENGTH_SHORT).show();
            return;
        }

        String userId = auth.getCurrentUser().getUid();

        Map<String, Object> cartItem = new HashMap<>();
        cartItem.put("productId", productId);
        cartItem.put("name", name);
        cartItem.put("price", price);
        cartItem.put("imageUrl", imageUrl);
        cartItem.put("merchantUid", merchantUid);
        cartItem.put("quantity", 1);

        db.collection("users")
                .document(userId)
                .collection("cart")
                .document(productId)
                .set(cartItem)
                .addOnSuccessListener(unused -> {
                    Toast.makeText(this, "Added to Cart", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(ProductDetailsActivity.this, CartActivity.class));
                })
                .addOnFailureListener(e ->
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }
}
