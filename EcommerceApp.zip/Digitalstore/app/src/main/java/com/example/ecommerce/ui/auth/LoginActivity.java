package com.example.ecommerce.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.DashboardActivity;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;

public class LoginActivity extends AppCompatActivity {

    private LinearLayout signInContainer, signUpContainer;
    private Button toggleButton, signupButton, loginButton;
    private SignInButton googleSignInButton;

    private EditText signupUsername, signupEmail, signupPassword, loginEmail, loginPassword;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private GoogleSignInClient mGoogleSignInClient;
    private final int RC_SIGN_IN = 100;
    private boolean isLoginVisible = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Firebase
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Views
        signInContainer = findViewById(R.id.signInContainer);
        signUpContainer = findViewById(R.id.signUpContainer);
        toggleButton = findViewById(R.id.toggleButton);
        googleSignInButton = findViewById(R.id.googleSignInButton);

        signupUsername = findViewById(R.id.signupUsername);
        signupEmail = findViewById(R.id.signupEmail);
        signupPassword = findViewById(R.id.signupPassword);

        loginEmail = findViewById(R.id.loginEmail);
        loginPassword = findViewById(R.id.loginPassword);

        signupButton = findViewById(R.id.signupButton);
        loginButton = findViewById(R.id.loginButton);

        // Initial visibility
        signInContainer.setVisibility(View.VISIBLE);
        signUpContainer.setVisibility(View.GONE);
        toggleButton.setText("Click to Sign Up");

        // Toggle
        toggleButton.setOnClickListener(v -> {
            if (isLoginVisible) {
                signInContainer.setVisibility(View.GONE);
                signUpContainer.setVisibility(View.VISIBLE);
                toggleButton.setText("Back to Login");
                isLoginVisible = false;
            } else {
                signUpContainer.setVisibility(View.GONE);
                signInContainer.setVisibility(View.VISIBLE);
                toggleButton.setText("Click to Sign Up");
                isLoginVisible = true;
            }
        });

        // Email Signup
        signupButton.setOnClickListener(v -> {
            String name = signupUsername.getText().toString().trim();
            String email = signupEmail.getText().toString().trim();
            String password = signupPassword.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null) {
                                // Send email verification
                                user.sendEmailVerification().addOnCompleteListener(emailTask -> {
                                    if (emailTask.isSuccessful()) {
                                        // Save username in Firestore
                                        db.collection("users").document(user.getUid())
                                                .set(new User(name, email, user.getUid()));

                                        showPopup("Sign Up Successful",
                                                "Verification email sent to: " + email + "\nCheck your inbox and verify to login.",
                                                () -> {
                                                    signUpContainer.setVisibility(View.GONE);
                                                    signInContainer.setVisibility(View.VISIBLE);
                                                    toggleButton.setText("Click to Sign Up");
                                                    isLoginVisible = true;

                                                    signupUsername.setText("");
                                                    signupEmail.setText("");
                                                    signupPassword.setText("");
                                                });
                                    }
                                });
                            }
                        } else {
                            Toast.makeText(this, "Sign Up Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });

        // Email Login
        loginButton.setOnClickListener(v -> {
            String email = loginEmail.getText().toString().trim();
            String password = loginPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            if (user != null && user.isEmailVerified()) {
                                // Fetch name from Firestore
                                db.collection("users").document(user.getUid())
                                        .get()
                                        .addOnSuccessListener(document -> {
                                            String name = document.getString("name");
                                            showPopup("Login Successful",
                                                    "Welcome back, " + name + "!",
                                                    this::navigateToHome);
                                        });
                            } else {
                                Toast.makeText(this, "Verify your email first", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(this, "Login Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });

        // Google Sign-In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        googleSignInButton.setOnClickListener(v -> signInWithGoogle());
    }

    private void signInWithGoogle() {
        startActivityForResult(mGoogleSignInClient.getSignInIntent(), RC_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(Exception.class);
                if (account != null) firebaseAuthWithGoogle(account.getIdToken(), account.getDisplayName(), account.getEmail());
            } catch (Exception e) {
                Toast.makeText(this, "Google Sign-In Failed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void firebaseAuthWithGoogle(String idToken, String name, String email) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                FirebaseUser user = mAuth.getCurrentUser();
                if (user != null) {
                    // Save in Firestore if first-time user
                    db.collection("users").document(user.getUid())
                            .set(new User(name, email, user.getUid()));

                    showPopup("Welcome!", "Hello, " + name + "!", this::navigateToHome);
                }
            } else {
                Toast.makeText(this, "Firebase Auth Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void navigateToHome() {
        startActivity(new Intent(this, DashboardActivity.class));
        finish();
    }

    private void showPopup(String title, String message, Runnable onOkAction) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", (dialog, which) -> {
                    if (onOkAction != null) onOkAction.run();
                    dialog.dismiss();
                })
                .show();
    }
}
