package com.example.ecommerce.admin;

import com.example.ecommerce.admin.Adapter.UserAdapter;
import com.example.ecommerce.admin.model.User;
import com.example.ecommerce.R;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;

public class UserManagementActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<User> userList;
    private UserAdapter userAdapter;

    private FirebaseFirestore db;
    private CollectionReference userRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_management);

        recyclerView = findViewById(R.id.recyclerUsers);

        db = FirebaseFirestore.getInstance();
        userRef = db.collection("users");

        userList = new ArrayList<>();
        userAdapter = new UserAdapter(userList, userRef, new UserAdapter.OnItemClickListener() {
            @Override
            public void onEdit(User user) {
                showUserDialog(user, true);
            }

            @Override
            public void onDelete(User user) {
                if (user.getUserId() != null) {
                    userRef.document(user.getUserId()).delete()
                            .addOnSuccessListener(aVoid ->
                                    Toast.makeText(UserManagementActivity.this, "User Deleted", Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e ->
                                    Toast.makeText(UserManagementActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(userAdapter);

        loadUsers();

        findViewById(R.id.btnAddUser).setOnClickListener(v -> showUserDialog(null, false));
    }

    private void loadUsers() {
        userRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Toast.makeText(UserManagementActivity.this, "Error loading users!", Toast.LENGTH_SHORT).show();
                    return;
                }

                userList.clear();
                for (DocumentSnapshot snapshot : value.getDocuments()) {
                    User user = snapshot.toObject(User.class);
                    if (user != null) {
                        user.setUserId(snapshot.getId());
                        userList.add(user);
                    }
                }
                userAdapter.notifyDataSetChanged();
            }
        });
    }

    private void showUserDialog(@Nullable User user, boolean isEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isEdit ? "Edit User" : "Add User");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20, 20, 20, 20);

        final EditText edtName = new EditText(this);
        edtName.setHint("Name");
        if (isEdit) edtName.setText(user.getName());
        layout.addView(edtName);

        final EditText edtEmail = new EditText(this);
        edtEmail.setHint("Email");
        if (isEdit) edtEmail.setText(user.getEmail());
        layout.addView(edtEmail);

        final EditText edtPhone = new EditText(this);
        edtPhone.setHint("Phone");
        edtPhone.setInputType(InputType.TYPE_CLASS_PHONE);
        if (isEdit) edtPhone.setText(user.getPhone());
        layout.addView(edtPhone);

        builder.setView(layout);

        builder.setPositiveButton(isEdit ? "Update" : "Add", (dialog, which) -> {
            String name = edtName.getText().toString().trim();
            String email = edtEmail.getText().toString().trim();
            String phone = edtPhone.getText().toString().trim();

            if (!name.isEmpty() && !email.isEmpty() && !phone.isEmpty()) {
                String id = isEdit ? user.getUserId() : userRef.document().getId();
                User newUser = new User(id, name, email, phone);
                userRef.document(id).set(newUser)
                        .addOnSuccessListener(aVoid ->
                                Toast.makeText(UserManagementActivity.this, isEdit ? "User Updated" : "User Added", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e ->
                                Toast.makeText(UserManagementActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}