package com.example.ecommerce.admin;

import com.example.ecommerce.admin.Slide;

public interface SlideActions {
    void deleteSlide(Slide slide);
    void editSlide(Slide slide);
}
