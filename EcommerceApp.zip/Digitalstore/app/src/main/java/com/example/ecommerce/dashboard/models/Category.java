package com.example.ecommerce.dashboard.models;

public class Category {
    private String name;
    private String iconUrl;    // For online images
    private String iconName;   // For local drawable resources

    // Default constructor
    public Category() {}

    // Constructor for online images
    public Category(String name, String iconUrl) {
        this.name = name;
        this.iconUrl = iconUrl;
    }

    // Constructor for local drawable resources
    public Category(String name, String iconName, boolean isLocal) {
        this.name = name;
        if (isLocal) {
            this.iconName = iconName;
        } else {
            this.iconUrl = iconName;
        }
    }

    // Getters & Setters
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getIconUrl() { return iconUrl; }
    public void setIconUrl(String iconUrl) { this.iconUrl = iconUrl; }

    public String getIconName() { return iconName; }  // Added for local drawables
    public void setIconName(String iconName) { this.iconName = iconName; }
}
