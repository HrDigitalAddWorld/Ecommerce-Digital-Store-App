package com.example.ecommerce;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;
import java.util.ArrayList;
import java.util.HashMap;

public class ChatbotActivity extends AppCompatActivity {

    EditText etMessage;
    Button btnSend;
    ListView listViewChat;
    ArrayList<HashMap<String, String>> chatList;
    SimpleAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        etMessage = findViewById(R.id.etMessage);
        btnSend = findViewById(R.id.btnSend);
        listViewChat = findViewById(R.id.listViewChat);

        chatList = new ArrayList<>();

        adapter = new SimpleAdapter(
                this,
                chatList,
                0,
                new String[]{"message"},
                new int[]{R.id.tvMessage}) {

            @Override
            public android.view.View getView(int position, android.view.View convertView, android.view.ViewGroup parent) {
                HashMap<String, String> chat = chatList.get(position);
                String type = chat.get("type");
                String message = chat.get("message");

                if (type.equals("user")) {
                    convertView = getLayoutInflater().inflate(R.layout.item_user_message, parent, false);
                } else {
                    convertView = getLayoutInflater().inflate(R.layout.item_bot_message, parent, false);
                }

                TextView tvMessage = convertView.findViewById(R.id.tvMessage);
                tvMessage.setText(message);
                return convertView;
            }
        };

        listViewChat.setAdapter(adapter);

        btnSend.setOnClickListener(v -> {
            String userMessage = etMessage.getText().toString().trim();
            if (!userMessage.isEmpty()) {
                addMessage("user", userMessage);
                etMessage.setText("");
                String botReply = getBotResponse(userMessage);
                addMessage("bot", botReply);
            }
        });
    }

    private void addMessage(String type, String message) {
        HashMap<String, String> map = new HashMap<>();
        map.put("type", type);
        map.put("message", message);
        chatList.add(map);
        adapter.notifyDataSetChanged();
        listViewChat.smoothScrollToPosition(chatList.size() - 1);
    }

    private String getBotResponse(String msg) {
        msg = msg.toLowerCase();

        // Greetings
        if (msg.contains("hello") || msg.contains("hi") || msg.contains("hey")) {
            return "Hello! How can I assist you today?";
        } else if (msg.contains("good morning") || msg.contains("good afternoon") || msg.contains("good evening")) {
            return "Hello! How can I help you today?";
        }

        // Orders
        else if (msg.contains("order") || msg.contains("track order") || msg.contains("my order")) {
            return "You can track your order in the 'My Orders' section.";
        } else if (msg.contains("cancel order")) {
            return "You can cancel an order from 'My Orders' if it hasn't been shipped yet.";
        }

        // Payment
        else if (msg.contains("payment") || msg.contains("pay") || msg.contains("cash on delivery")) {
            return "We support multiple payment methods including Credit/Debit Cards, UPI, Wallets, and Cash on Delivery.";
        }

        // Delivery
        else if (msg.contains("delivery") || msg.contains("shipping") || msg.contains("arrive")) {
            return "Orders are usually delivered within 3–7 business days depending on your location.";
        }

        // Products
        else if (msg.contains("price") || msg.contains("cost") || msg.contains("how much")) {
            return "You can check product prices in the product details section.";
        } else if (msg.contains("available") || msg.contains("stock")) {
            return "Please check the product page for availability and stock information.";
        } else if (msg.contains("product") || msg.contains("item")) {
            return "You can browse products by category or use the search bar to find a specific item.";
        }

        // Promotions
        else if (msg.contains("offer") || msg.contains("discount") || msg.contains("sale") || msg.contains("coupon")) {
            return "We regularly have discounts and promotions. Check the 'Deals of the Day' section or subscribe to notifications for offers.";
        }

        // Account/Login
        else if (msg.contains("login") || msg.contains("sign in") || msg.contains("account")) {
            return "Please login to access your account features, track orders, and manage your profile.";
        } else if (msg.contains("signup") || msg.contains("register") || msg.contains("create account")) {
            return "You can create a new account by clicking on the 'Sign Up' button on the home page.";
        }

        // Return / Refund
        else if (msg.contains("return") || msg.contains("refund")) {
            return "You can initiate a return or refund request from 'My Orders' for eligible products.";
        }

        // Support / Help
        else if (msg.contains("help") || msg.contains("support") || msg.contains("customer care") || msg.contains("contact")) {
            return "You can contact our support team via the 'Contact Us' section or email support@example.com.";
        }

        // Polite / Thanks
        else if (msg.contains("thank") || msg.contains("thanks")) {
            return "You're welcome! 😊";
        } else if (msg.contains("bye") || msg.contains("goodbye") || msg.contains("see you")) {
            return "Goodbye! Have a great day! 👋";
        }

        // Fallback
        else {
            return "I'm not sure about that. Please contact support for more help or try asking something else.";
        }
    }
}