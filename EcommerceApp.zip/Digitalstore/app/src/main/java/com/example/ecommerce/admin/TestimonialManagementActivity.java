package com.example.ecommerce.admin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.example.ecommerce.admin.model.Testimonial;
import com.example.ecommerce.admin.Adapter.TestimonialAdapter;
import com.example.ecommerce.R;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class TestimonialManagementActivity extends AppCompatActivity {

    private EditText edtUserName, edtMessage;
    private Button btnAddTestimonial;
    private RecyclerView recyclerTestimonials;

    private FirebaseFirestore firestore;
    private List<Testimonial> testimonialList;
    private TestimonialAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testimonial_management);

        edtUserName = findViewById(R.id.edtUserName);
        edtMessage = findViewById(R.id.edtMessage);
        btnAddTestimonial = findViewById(R.id.btnAddTestimonial);
        recyclerTestimonials = findViewById(R.id.recyclerTestimonials);

        firestore = FirebaseFirestore.getInstance();
        testimonialList = new ArrayList<>();
        adapter = new TestimonialAdapter(testimonialList, this);
        recyclerTestimonials.setLayoutManager(new LinearLayoutManager(this));
        recyclerTestimonials.setAdapter(adapter);

        loadTestimonials();

        btnAddTestimonial.setOnClickListener(v -> addTestimonial());
    }

    private void addTestimonial() {
        String name = edtUserName.getText().toString().trim();
        String message = edtMessage.getText().toString().trim();

        if (name.isEmpty() || message.isEmpty()) {
            Toast.makeText(this, "Fill both fields", Toast.LENGTH_SHORT).show();
            return;
        }

        Testimonial testimonial = new Testimonial(name, message);

        firestore.collection("testimonials")
                .add(testimonial)
                .addOnSuccessListener(docRef -> {
                    Toast.makeText(this, "Testimonial added", Toast.LENGTH_SHORT).show();
                    testimonialList.add(testimonial);
                    adapter.notifyItemInserted(testimonialList.size() - 1);
                    edtUserName.setText("");
                    edtMessage.setText("");
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to add testimonial", Toast.LENGTH_SHORT).show());
    }

    private void loadTestimonials() {
        firestore.collection("testimonials")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        testimonialList.clear();
                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            Testimonial t = doc.toObject(Testimonial.class);
                            testimonialList.add(t);
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(this, "Failed to load testimonials", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}