package com.example.ecommerce.admin;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.ecommerce.admin.Adapter.PaymentSettlementAdapter;
import com.example.ecommerce.admin.model.PaymentSettlement;
import com.example.ecommerce.R;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class PaymentSettlementActivity extends AppCompatActivity {

    private RecyclerView recyclerViewSettlement;
    private PaymentSettlementAdapter adapter;
    private List<PaymentSettlement> settlementList;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_settlement);

        recyclerViewSettlement = findViewById(R.id.recyclerViewSettlement);
        settlementList = new ArrayList<>();
        adapter = new PaymentSettlementAdapter(settlementList);
        recyclerViewSettlement.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewSettlement.setAdapter(adapter);

        db = FirebaseFirestore.getInstance();

        loadSettlements();

        findViewById(R.id.btnAddSettlement).setOnClickListener(v -> showAddSettlementDialog());
    }

    // Load all settlements from root collection "PaymentSettlements"
    private void loadSettlements() {
        db.collection("PaymentSettlements")
                .orderBy("date", Query.Direction.DESCENDING) // ordering works with date strings but may be lexicographical
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    settlementList.clear();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        PaymentSettlement settlement = doc.toObject(PaymentSettlement.class);
                        settlementList.add(settlement);
                    }
                    adapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(PaymentSettlementActivity.this, "Failed to load data: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private void showAddSettlementDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Payment Settlement");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        final EditText sellerNameInput = new EditText(this);
        sellerNameInput.setHint("Seller Name");
        layout.addView(sellerNameInput);

        final EditText amountInput = new EditText(this);
        amountInput.setHint("Amount");
        amountInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        layout.addView(amountInput);

        builder.setView(layout);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String sellerName = sellerNameInput.getText().toString().trim();
            String amount = amountInput.getText().toString().trim();

            if (!sellerName.isEmpty() && !amount.isEmpty()) {
                String id = db.collection("PaymentSettlements").document().getId();
                String date = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(new Date());

                PaymentSettlement settlement = new PaymentSettlement(id, sellerName, amount, date);

                db.collection("PaymentSettlements")
                        .document(id)
                        .set(settlement)
                        .addOnSuccessListener(aVoid ->
                                Toast.makeText(this, "Settlement Added", Toast.LENGTH_SHORT).show()
                        )
                        .addOnFailureListener(e ->
                                Toast.makeText(this, "Failed to add settlement: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                        );

            } else {
                Toast.makeText(this, "All fields required", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}