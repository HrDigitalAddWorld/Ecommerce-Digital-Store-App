package com.example.ecommerce.admin;

import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.ArrayList;
import java.util.List;
import com.example.ecommerce.admin.model.Order;
import com.example.ecommerce.admin.Adapter.OrderAdapter;
import com.example.ecommerce.R;

public class OrderManagementActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private List<Order> orderList;
    private OrderAdapter orderAdapter;

    private FirebaseFirestore db;
    private CollectionReference orderRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_management);

        recyclerView = findViewById(R.id.recyclerOrders);
        db = FirebaseFirestore.getInstance();
        orderRef = db.collection("orders");

        orderList = new ArrayList<>();
        orderAdapter = new OrderAdapter(orderList, orderRef, new OrderAdapter.OnItemClickListener() {
            @Override
            public void onEdit(Order order) {
                showOrderDialog(order, true);
            }

            @Override
            public void onDelete(Order order) {
                if (order.getOrderId() != null) {
                    orderRef.document(order.getOrderId()).delete()
                            .addOnSuccessListener(aVoid ->
                                    Toast.makeText(OrderManagementActivity.this, "Order Deleted", Toast.LENGTH_SHORT).show())
                            .addOnFailureListener(e ->
                                    Toast.makeText(OrderManagementActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
                }
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(orderAdapter);

        loadOrders();

        findViewById(R.id.btnAddOrder).setOnClickListener(v -> showOrderDialog(null, false));
    }

    private void loadOrders() {
        orderRef.addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Toast.makeText(OrderManagementActivity.this, "Error loading orders!", Toast.LENGTH_SHORT).show();
                    return;
                }

                orderList.clear();
                for (DocumentSnapshot snapshot : value.getDocuments()) {
                    Order order = snapshot.toObject(Order.class);
                    if (order != null) {
                        order.setOrderId(snapshot.getId());
                        orderList.add(order);
                    }
                }
                orderAdapter.notifyDataSetChanged();
            }
        });
    }

    private void showOrderDialog(@Nullable Order order, boolean isEdit) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(isEdit ? "Edit Order" : "Add Order");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(20, 20, 20, 20);

        final EditText edtCustomer = new EditText(this);
        edtCustomer.setHint("Customer Name");
        if (isEdit) edtCustomer.setText(order.getCustomerName());
        layout.addView(edtCustomer);

        final EditText edtProduct = new EditText(this);
        edtProduct.setHint("Product Name");
        if (isEdit) edtProduct.setText(order.getProductName());
        layout.addView(edtProduct);

        final EditText edtQty = new EditText(this);
        edtQty.setHint("Quantity");
        edtQty.setInputType(InputType.TYPE_CLASS_NUMBER);
        if (isEdit) edtQty.setText(String.valueOf(order.getQty()));
        layout.addView(edtQty);

        final EditText edtAmount = new EditText(this);
        edtAmount.setHint("Amount");
        edtAmount.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_CLASS_NUMBER);
        if (isEdit) edtAmount.setText(String.valueOf(order.getAmount()));
        layout.addView(edtAmount);

        final EditText edtStatus = new EditText(this);
        edtStatus.setHint("Status");
        if (isEdit) edtStatus.setText(order.getStatusString());
        layout.addView(edtStatus);

        builder.setView(layout);

        builder.setPositiveButton(isEdit ? "Update" : "Add", (dialog, which) -> {
            String customer = edtCustomer.getText().toString().trim();
            String product = edtProduct.getText().toString().trim();
            String qtyStr = edtQty.getText().toString().trim();
            String amountStr = edtAmount.getText().toString().trim();
            String statusStr = edtStatus.getText().toString().trim();

            if (!customer.isEmpty() && !product.isEmpty() && !qtyStr.isEmpty() && !amountStr.isEmpty() && !statusStr.isEmpty()) {
                int qty = Integer.parseInt(qtyStr);
                double amount = Double.parseDouble(amountStr);

                String id = isEdit ? order.getOrderId() : orderRef.document().getId();
                Order newOrder = new Order(id, customer, product, qty, amount, statusStr);
                orderRef.document(id).set(newOrder)
                        .addOnSuccessListener(aVoid ->
                                Toast.makeText(OrderManagementActivity.this, isEdit ? "Order Updated" : "Order Added", Toast.LENGTH_SHORT).show())
                        .addOnFailureListener(e ->
                                Toast.makeText(OrderManagementActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}