package com.example.ecommerce.data.db;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "orders")
public class orderr {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String orderName;
    private double totalAmount;

    private String orderDate;  // ya Date type bhi use kar sakte ho


    // Constructor WITHOUT id
    public orderr(String orderName, double totalAmount,String orderDate) {
        this.orderName = orderName;
        this.totalAmount = totalAmount;
        this.orderDate = orderDate;
    }

    // --- Getters ---
    public int getId() {
        return id;
    }

    public String getOrderName() {
        return orderName;
    }

    public double getTotalAmount() {
        return totalAmount;
    }
    public String getOrderDate() {
        return orderDate;
    }


    // --- Setters ---
    public void setId(int id) {   // <-- Yahan add karo
        this.id = id;
    }

    public void setOrderName(String orderName) {
        this.orderName = orderName;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

}
