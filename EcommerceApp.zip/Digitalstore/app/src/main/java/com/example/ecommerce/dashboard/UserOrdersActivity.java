package com.example.ecommerce.dashboard;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ecommerce.R;
import com.example.ecommerce.dashboard.models.Order;
import com.example.ecommerce.dashboard.adapters.OrderAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UserOrdersActivity extends AppCompatActivity {

    private RecyclerView ordersRecycler;
    private OrderAdapter orderAdapter;
    private List<Order> orderList;

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_orders);

        ordersRecycler = findViewById(R.id.ordersRecycler);
        ordersRecycler.setLayoutManager(new LinearLayoutManager(this));

        orderList = new ArrayList<>();
        orderAdapter = new OrderAdapter(this, orderList);
        ordersRecycler.setAdapter(orderAdapter);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        fetchUserOrders();
    }

    private void fetchUserOrders() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            Toast.makeText(this, "User not logged in!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        String userId = currentUser.getUid();
        Log.d("UserOrders", "Current user ID: " + userId);

        db.collection("orders")
                .whereEqualTo("userId", userId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        orderList.clear();

                        for (QueryDocumentSnapshot doc : task.getResult()) {
                            String orderId = doc.getId();

                            long timestamp = doc.contains("timestamp") && doc.getLong("timestamp") != null
                                    ? doc.getLong("timestamp") : 0;
                            String orderDate = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm")
                                    .format(new java.util.Date(timestamp));

                            String grandTotal = doc.contains("grandTotal") ? String.valueOf(doc.get("grandTotal")) : "0";

                            // Collect all merchant UIDs from items
                            List<Map<String, Object>> items = (List<Map<String, Object>>) doc.get("items");
                            Set<String> merchantSet = new HashSet<>();
                            if (items != null) {
                                for (Map<String, Object> item : items) {
                                    String mUid = (String) item.get("merchantUid");
                                    if (mUid != null) merchantSet.add(mUid);
                                }
                            }
                            String merchantUidStr = String.join(", ", merchantSet);

                            // --- Build status map ---
                            Map<String, Boolean> statusMap = new HashMap<>();
                            Object statusObj = doc.get("status");
                            if (statusObj instanceof Map) {
                                Map<?, ?> mapObj = (Map<?, ?>) statusObj;
                                for (Map.Entry<?, ?> entry : mapObj.entrySet()) {
                                    String key = entry.getKey() != null ? entry.getKey().toString() : "";
                                    boolean value = false;
                                    Object val = entry.getValue();
                                    if (val instanceof Boolean) value = (Boolean) val;
                                    else if (val instanceof String) value = Boolean.parseBoolean((String) val);

                                    // Normalize keys
                                    if (key.equalsIgnoreCase("orderPlaced") || key.equalsIgnoreCase("placed")) key = "orderPlaced";
                                    if (key.equalsIgnoreCase("shipped")) key = "shipped";
                                    if (key.equalsIgnoreCase("outForDelivery") || key.equalsIgnoreCase("out_for_delivery")) key = "outForDelivery";
                                    if (key.equalsIgnoreCase("delivered")) key = "delivered";

                                    statusMap.put(key, value);
                                }
                            } else if (statusObj instanceof String) {
                                String statusStr = ((String) statusObj).toLowerCase();
                                statusMap.put("orderPlaced", statusStr.contains("orderplaced") || statusStr.contains("placed"));
                                statusMap.put("shipped", statusStr.contains("shipped"));
                                statusMap.put("outForDelivery", statusStr.contains("outfordelivery"));
                                statusMap.put("delivered", statusStr.contains("delivered"));
                            }

                            // Infer orderPlaced if missing but other flags exist
                            if (!statusMap.containsKey("orderPlaced")) {
                                boolean inferredPlaced = statusMap.get("shipped") != null && statusMap.get("shipped")
                                        || statusMap.get("outForDelivery") != null && statusMap.get("outForDelivery")
                                        || statusMap.get("delivered") != null && statusMap.get("delivered");
                                statusMap.put("orderPlaced", inferredPlaced);
                            }

                            // Ensure all keys exist (API 23 safe)
                            if (!statusMap.containsKey("shipped")) statusMap.put("shipped", false);
                            if (!statusMap.containsKey("outForDelivery")) statusMap.put("outForDelivery", false);
                            if (!statusMap.containsKey("delivered")) statusMap.put("delivered", false);

                            String currentStatus = getCurrentStatus(statusMap);

                            orderList.add(new Order(orderId, orderDate, grandTotal, currentStatus, merchantUidStr, statusMap));

                            Log.d("UserOrders_Debug", "Order " + orderId + " statusMap: " + statusMap);
                        }

                        orderAdapter.notifyDataSetChanged();
                        Log.d("UserOrders", "Orders fetched: " + orderList.size());
                    } else {
                        Log.e("UserOrders", "Failed to fetch orders", task.getException());
                    }
                });
    }

    private String getCurrentStatus(Map<String, Boolean> statusMap) {
        boolean orderPlaced = Boolean.TRUE.equals(statusMap.get("orderPlaced"));
        boolean shipped = Boolean.TRUE.equals(statusMap.get("shipped"));
        boolean outForDelivery = Boolean.TRUE.equals(statusMap.get("outForDelivery"));
        boolean delivered = Boolean.TRUE.equals(statusMap.get("delivered"));

        if (!orderPlaced) return "Pending";                 // fallback if no info
        if (!shipped) return "Order Placed";                // only placed
        if (shipped && !outForDelivery) return "Shipped";  // shipped, not out for delivery
        if (outForDelivery && !delivered) return "Out for Delivery"; // out for delivery
        if (delivered) return "Delivered";                 // fully delivered
        return "Order Placed";                              // fallback
    }
}
