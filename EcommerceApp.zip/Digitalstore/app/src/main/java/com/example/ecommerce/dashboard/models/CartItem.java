package com.example.ecommerce.dashboard.models;

import java.io.Serializable;

public class CartItem implements Serializable { // <-- implement Serializable

    private String name;
    private String price;
    private int quantity;
    private String merchantUid;

    private String productId;

    public CartItem() { }

    public CartItem(String productId, String name, String price, int quantity, String merchantUid) {
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.merchantUid = merchantUid;
    }


    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public String getMerchantUid() { return merchantUid; }
    public void setMerchantUid(String merchantUid) { this.merchantUid = merchantUid; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }
}
