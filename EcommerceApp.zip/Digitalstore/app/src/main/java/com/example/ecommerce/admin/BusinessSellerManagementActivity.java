package com.example.ecommerce.admin;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.ecommerce.R;

public class BusinessSellerManagementActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_seller_management);

        TextView title = findViewById(R.id.dummyTitle);
        title.setText("Business Seller Management");
    }
}