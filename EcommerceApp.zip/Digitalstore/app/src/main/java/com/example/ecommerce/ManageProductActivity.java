package com.example.ecommerce;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class ManageProductActivity extends AppCompatActivity {

    private RecyclerView rvMerchantProducts;
    private ProductAdapter productAdapter;
    private List<Product> productList;
    private FirebaseFirestore db;
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_products);

        rvMerchantProducts = findViewById(R.id.rvMerchantProducts);
        rvMerchantProducts.setLayoutManager(new LinearLayoutManager(this));

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        productList = new ArrayList<>();
        productAdapter = new ProductAdapter(this, productList);
        rvMerchantProducts.setAdapter(productAdapter);

        fetchMerchantProducts();
    }

    private void fetchMerchantProducts() {
        String merchantId = auth.getCurrentUser().getUid();
        Log.d("ManageProductActivity", "Current merchant UID: " + merchantId);

        db.collection("products") // note lowercase 'products' to match AddProductActivity
                .whereEqualTo("merchantUid", merchantId) // match the exact field used
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    productList.clear();
                    if(queryDocumentSnapshots.isEmpty()) {
                        Log.d("ManageProductActivity", "No products found for this merchant.");
                    } else {
                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                            Product product = document.toObject(Product.class);
                            product.setId(document.getId());
                            productList.add(product);
                            Log.d("ManageProductActivity", "Product loaded: " + product.getProductName()); // <-- changed here
                        }

                    }
                    productAdapter.notifyDataSetChanged();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to load products", Toast.LENGTH_SHORT).show();
                    Log.e("ManageProductActivity", "Error: " + e.getMessage());
                });

    }
}
