package com.example.ecommerce.admin.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.ecommerce.R;
import com.example.ecommerce.admin.model.PaymentSettlement;


import java.util.List;

public class PaymentSettlementAdapter extends RecyclerView.Adapter<PaymentSettlementAdapter.SettlementViewHolder> {

    private List<PaymentSettlement> settlementList;

    public PaymentSettlementAdapter(List<PaymentSettlement> settlementList) {
        this.settlementList = settlementList;
    }

    @NonNull
    @Override
    public SettlementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_payment_settlement, parent, false);
        return new SettlementViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SettlementViewHolder holder, int position) {
        PaymentSettlement settlement = settlementList.get(position);
        holder.txtSellerName.setText(settlement.getSellerName());
        holder.txtAmount.setText("₹" + settlement.getAmount());
        holder.txtDate.setText(settlement.getDate());
    }

    @Override
    public int getItemCount() {
        return settlementList.size();
    }

    static class SettlementViewHolder extends RecyclerView.ViewHolder {
        TextView txtSellerName, txtAmount, txtDate;

        public SettlementViewHolder(@NonNull View itemView) {
            super(itemView);
            txtSellerName = itemView.findViewById(R.id.txtSellerName);
            txtAmount = itemView.findViewById(R.id.txtAmount);
            txtDate = itemView.findViewById(R.id.txtDate);
        }
    }
}