package com.example.ecommerce;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class EarningsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product); // We'll create this layout next
    }
}
