package com.example.ecommerce.admin;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.ecommerce.R;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class DealManagementActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 100;
    private Uri selectedImageUri;

    private RecyclerView recyclerView;
    private DealAdapter adapter;
    private List<Deal> dealList = new ArrayList<>();
    private Button addDealBtn;

    private StorageReference storageRef;
    private DatabaseReference databaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal_management);

        recyclerView = findViewById(R.id.recyclerViewDeals);
        addDealBtn = findViewById(R.id.btnAddDeal);

        recyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        adapter = new DealAdapter(this, dealList);
        recyclerView.setAdapter(adapter);

        storageRef = FirebaseStorage.getInstance().getReference("deals");
        databaseRef = FirebaseDatabase.getInstance().getReference("deals");

        addDealBtn.setOnClickListener(v -> openAddDealDialog());

        loadDeals();
    }

    private void openAddDealDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Deal");

        EditText input = new EditText(this);
        input.setHint("Enter Deal Title");
        builder.setView(input);

        builder.setPositiveButton("Select Image", (dialog, which) -> pickImage());
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());

        builder.setNeutralButton("Upload Deal", (dialog, which) -> {
            String title = input.getText().toString().trim();
            if (title.isEmpty() || selectedImageUri == null) {
                Toast.makeText(this, "Please select image and enter title", Toast.LENGTH_SHORT).show();
                return;
            }
            uploadDeal(title, selectedImageUri);
        });

        builder.show();
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, "Select Deal Image"), PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImageUri = data.getData();
        }
    }

    private void uploadDeal(String title, Uri imageUri) {
        StorageReference fileRef = storageRef.child(System.currentTimeMillis() + ".jpg");
        fileRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> fileRef.getDownloadUrl()
                        .addOnSuccessListener(uri -> {
                            Deal deal = new Deal(title, uri.toString());
                            databaseRef.push().setValue(deal)
                                    .addOnSuccessListener(aVoid -> {
                                        dealList.add(deal);
                                        adapter.notifyDataSetChanged();
                                        selectedImageUri = null;
                                        Toast.makeText(this, "Deal Added", Toast.LENGTH_SHORT).show();
                                    });
                        }))
                .addOnFailureListener(e -> Toast.makeText(this, "Upload Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void loadDeals() {
        databaseRef.get().addOnSuccessListener(snapshot -> {
            dealList.clear();
            for(DataSnapshot child : snapshot.getChildren()) {
                Deal deal = child.getValue(Deal.class);
                if(deal != null) dealList.add(deal);
            }
            adapter.notifyDataSetChanged();
        });
    }
}